const { MessageEmbed } = require("discord.js");
const { getSettings } = require("@schemas/Guild");

/**
 * @param {import('@src/structures').BotClient} client
 * @param {import('discord.js').Guild} guild
 */
module.exports = async (client, guild) => {
  client.logger.log(`Guild Left: ${guild.name} Members: ${guild.memberCount}`);

  const settings = await getSettings(guild);
  settings.data.leftAt = new Date();
  await settings.save();

  if (!client.joinLeaveWebhook) return;

  let ownerTag;
  const ownerId = guild.ownerId || settings.data.owner.id;
  try {
    const owner = await client.users.fetch(guild.ownerId);
    ownerTag = owner.tag;
  } catch (err) {
    ownerTag = settings.data.owner.tag;
  }

  const embed = new MessageEmbed()
    .setTitle("📛__LEAVE SERVEUR__")
    .setThumbnail(guild.iconURL())
    .setColor("RANDOM")
    .addField("__Nom__", guild.name, false)
    .addField("__ID__", guild.id, false)
    .addField("__Owner__", `${client.users.cache.get(guild.ownerId).tag} [\`${guild.ownerId}\`]`, false)
    .addField("__Total__", `\`\`\`yaml\n${guild.memberCount}\`\`\``, false)
    .addField("__Membres__", `\`\`\`yaml\n${guild.members.cache.filter((m) => !m.user.bot).size}\`\`\``, false)
    .setFooter({ text: `Serveur #${client.guilds.cache.size}` });

  client.joinLeaveWebhook.send({
    username: "Leave",
    avatarURL: client.user.displayAvatarURL(),
    embeds: [embed],
  });
};
