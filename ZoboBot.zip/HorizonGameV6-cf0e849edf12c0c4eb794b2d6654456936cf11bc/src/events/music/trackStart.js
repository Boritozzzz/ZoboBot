const { MessageEmbed } = require("discord.js");
const prettyMs = require("pretty-ms");

/**
 * Emitted when a track starts.
 * @param {import("@src/structures").BotClient} client
 * @param {import("erela.js").Player} player
 * @param {import("erela.js").Track} track
 * @param {import("erela.js").TrackStartEvent} payload
 */
module.exports = (client, player, track, payload) => {
  const channel = client.channels.cache.get(player.textChannel);

  const embed = new MessageEmbed()
     .setTitle("<a:horizongame_cd:946880912803651645>__NOW PLAYING__")
    .setTimestamp()
    .setColor(client.config.EMBED_COLORS.BOT_EMBED)
    .setDescription(`[${track.title}](${track.uri})`)
    .addField("<:horlo:885097507699429376>__Durée__", "`" + prettyMs(track.duration, { colonNotation: true }) + "`", true)
    .setFooter({ text: `Ajouté par: ${track.requester.tag}` });

  if (typeof track.displayThumbnail === "function") embed.setThumbnail(track.displayThumbnail("hqdefault"));
  if (player.queue.totalSize > 0) embed.addField("__<:animeeee:885087722828611625>Position__", (player.queue.size - 0).toString(), true);
  channel.safeSend({ embeds: [embed] });
};
