/**
 * Emitted when a player queue ends.
 * @param {import("@src/structures").BotClient} client
 * @param {import("erela.js").Player} player
 */
module.exports = (client, player) => {
  const channel = client.channels.cache.get(player.textChannel);
  player.destroy();
  channel.safeSend("> <:emoji_25:885095917210988604> La file d'attente est terminée.");
};
