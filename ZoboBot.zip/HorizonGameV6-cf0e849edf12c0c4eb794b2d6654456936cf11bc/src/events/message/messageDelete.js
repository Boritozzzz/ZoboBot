const { MessageEmbed } = require("discord.js");
const { getSettings } = require("@schemas/Guild");

/**
 * @param {import('@src/structures').BotClient} client
 * @param {import('discord.js').Message|import('discord.js').PartialMessage} message
 */
module.exports = async (client, message) => {
  if (message.partial) return;
  if (message.author.bot || !message.guild) return;

  const settings = await getSettings(message.guild);
  if (!settings.automod.anti_ghostping || !settings.modlog_channel) return;
  const { members, roles, everyone } = message.mentions;

  // Check message if it contains mentions
  if (members.size > 0 || roles.size > 0 || everyone) {
    const logChannel = message.guild.channels.cache.get(settings.modlog_channel);
    if (!logChannel) return;

    const embed = new MessageEmbed()
      .setTitle("__ANTI GOSTPING__")
      .setColor("RANDOM")
      .setDescription(
        `<:emoji_44:885169331976163328>**__Message__:**\n${message.content}\n\n` +
          `<:emoji_44:885169331976163328>**__Auteur__:**\n${message.author.tag} \`${message.author.id}\`\n` +
          `<:emoji_44:885169331976163328>**__Salon__:**\n${message.channel.toString()}`
      )
      .addField("<:emoji_44:885169331976163328>__Membres__", members.size.toString(), true)
      .addField("<:emoji_44:885169331976163328>__Rôles__", roles.size.toString(), true)
      .addField("<:emoji_44:885169331976163328>__Everyone?__", everyone.toString(), true)
      .setFooter({ text: `Envoyé à: ${message.createdAt}` });

    logChannel.safeSend({ embeds: [embed] });
  }
};
