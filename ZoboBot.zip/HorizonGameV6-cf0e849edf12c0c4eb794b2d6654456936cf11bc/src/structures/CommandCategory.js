module.exports = {
  ADMIN: {
    name: "Admin",
    image: "https://icons.iconarchive.com/icons/dakirby309/simply-styled/256/Settings-icon.png",
    emoji: "<:hammers:885093621026680862>",
  },
  AUTOMOD: {
    name: "Automod",
    image: "https://icons.iconarchive.com/icons/dakirby309/simply-styled/256/Settings-icon.png",
    emoji: "<:role:885078141209567272>",
  },
  ANIME: {
    name: "Anime",
    image: "https://wallpaperaccess.com/full/5680679.jpg",
    emoji: "<:emoji_19:885087722828611625>",
  },
  ECONOMY: {
    name: "Économie",
    image: "https://icons.iconarchive.com/icons/custom-icon-design/pretty-office-11/128/coins-icon.png",
    emoji: "<:money:885078204476456980>",
  },
  FUN: {
    name: "Amusant",
    image: "https://icons.iconarchive.com/icons/flameia/aqua-smiles/128/make-fun-icon.png",
    emoji: "<:fun:885078041175400468>",
  },
  GIVEAWAY: {
    name: "Giveaway",
    image: "https://icons.iconarchive.com/icons/flameia/aqua-smiles/128/make-fun-icon.png",
    emoji: "<:emoji_21:885090857747877939>",
  },
  IMAGE: {
    name: "Image",
    image: "https://icons.iconarchive.com/icons/dapino/summer-holiday/128/photo-icon.png",
    emoji: "<:channel:885114386706993173>",
  },
  INVITE: {
    name: "Invite",
    image: "https://cdn4.iconfinder.com/data/icons/general-business/150/Invite-512.png",
    emoji: "<:invite:890196461030088714>",
  },
  INFORMATION: {
    name: "Information",
    image: "https://icons.iconarchive.com/icons/graphicloads/100-flat/128/information-icon.png",
    emoji: "<:search:885115865417261066>",
  },
  MODERATION: {
    name: "Modération",
    image: "https://icons.iconarchive.com/icons/lawyerwordpress/law/128/Gavel-Law-icon.png",
    emoji: "<:quest:885078225221480478>",
  },
  MUSIC: {
    name: "Musique",
    image: "https://icons.iconarchive.com/icons/wwalczyszyn/iwindows/256/Music-Library-icon.png",
    emoji: "<:music:885078247954595870>",
  },
  
  SOCIAL: {
    name: "Sociale",
    image: "https://icons.iconarchive.com/icons/dryicons/aesthetica-2/128/community-users-icon.png",
    emoji: "<:user:885128850806288385>",
  },
  
   SUGGESTION: {
    name: "Suggestion",
    image: "https://cdn-icons-png.flaticon.com/512/1484/1484815.png",
    emoji: "<:message:885133705025310740>",
  },
  
  TICKET: {
    name: "Ticket",
    image: "https://icons.iconarchive.com/icons/custom-icon-design/flatastic-2/512/ticket-icon.png",
    emoji: "<:support:890196360379400202>",
  },
  UTILITY: {
    name: "Utilité",
    image: "https://icons.iconarchive.com/icons/blackvariant/button-ui-system-folders-alt/128/Utilities-icon.png",
    emoji: "<:emoji_18:885087400534089728>",
  },
};
