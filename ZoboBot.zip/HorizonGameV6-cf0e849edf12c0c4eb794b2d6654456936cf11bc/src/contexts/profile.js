const { BaseContext } = require("@src/structures");
const { ContextMenuInteraction, MessageEmbed } = require("discord.js");
const { getSettings } = require("@schemas/Guild");
const { getUser } = require("@schemas/User");
const { getMember } = require("@schemas/Member");
const { EMBED_COLORS, ECONOMY } = require("@root/config");

module.exports = class Profile extends BaseContext {
  constructor(client) {
    super(client, {
      name: "profile",
      description: "obtenir le profil des utilisateurs",
      type: "USER",
      enabled: true,
      ephemeral: true,
    });
  }

  /**
   * @param {ContextMenuInteraction} interaction
   */
  async run(interaction) {
    const user = await interaction.client.users.fetch(interaction.targetId);
    const response = await profile(interaction, user);
    await interaction.followUp(response);
  }
};

async function profile({ guild }, user) {
  const settings = await getSettings(guild);
  const memberData = await getMember(guild.id, user.id);
  const userData = await getUser(user.id);

  const embed = new MessageEmbed()
    .setThumbnail(user.displayAvatarURL())
    .setColor(EMBED_COLORS.BOT_EMBED)
   .addField("**__Tag__**", user.tag, true)
    .addField("__**ID**__", user.id, true)
    .addField("**__Discord Registered__**", user.createdAt.toDateString(), false)
    .addField("**__Cash__**", `${userData.coins} ${ECONOMY.CURRENCY}`, true)
    .addField("**__Bank__**", `${userData.bank} ${ECONOMY.CURRENCY}`, true)
    .addField("**__Net Worth__**", `${userData.coins + userData.bank}${ECONOMY.CURRENCY}`, true)
    .addField("__**Reputation**__", `${userData.reputation.received}`, true)
    .addField("__**Daily Streak**__", `${userData.daily.streak}`, true)
    .addField("**__XP__**", `${settings.ranking.enabled ? memberData.xp + " " : "Not Tracked"}`, true)
    .addField("__**Level**__", `${settings.ranking.enabled ? memberData.level + " " : "Not Tracked"}`, true)
    .addField("__**Strikes**__", memberData.strikes + " ", true)
    .addField("__**Warnings**__", memberData.warnings + " ", true)
    .setFooter({ text: "Fields marked (*) are guild specific" });

  return { embeds: [embed] };
}
