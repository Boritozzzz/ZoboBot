module.exports = {
  automodHandler: require("./automod"),
  counterHandler: require("./counter"),
  greetingHandler: require("./greeting"),
  inviteHandler: require("./invite"),
  reactionHandler: require("./reaction"),
  xpHandler: require("./xp"),
};
