const { getSettings } = require("@schemas/Guild");
const { findSuggestion } = require("@schemas/Suggestions");
const { SUGGESTIONS } = require("@root/config");
const { MessageActionRow, MessageButton } = require("discord.js");

/**
 * @param {import('discord.js').Message} message
 */
const getStats = (message) => {
  return [
    message.reactions.cache.get("👍").count - 1,
    message.reactions.cache.get("👎").count - 1,
  ];
};

module.exports = {
  /**
   * @param {import('discord.js').Guild} guild
   * @param {import('discord.js').GuildMember} member
   * @param {string} messageId
   */
  async approveSuggestion(guild, member, messageId) {
    // validate permissions
    if (!member.permissions.has("MANAGE_GUILD")) return "Vous n'avez pas la permission d'approuver des suggestions!";

    // validate document
    const doc = await findSuggestion(guild.id, messageId);
    if (!doc) return "Suggestion non trouvée";
    if (doc.status === "APPROVED") return "Suggestion déjà approuvée";

    // validate channel
    const settings = await getSettings(guild);
    if (!settings.suggestions.channel_id) return "Suggestions salon non définies";
    const suggestionsChannel = guild.channels.cache.get(settings.suggestions.channel_id);
    if (!suggestionsChannel) return "Suggestions salon introuvable";

    let message;
    try {
      message = await suggestionsChannel.messages.fetch(messageId);
    } catch (err) {
      return "Message de Suggestion non trouvé";
    }

    let buttonsRow = new MessageActionRow().addComponents(
      new MessageButton().setCustomId("SUGGEST_APPROVE").setLabel("Approuver").setStyle("SUCCESS").setDisabled(true),
      new MessageButton().setCustomId("SUGGEST_REJECT").setLabel("Rejeter").setStyle("DANGER")
    );

    const approvedEmbed = message.embeds[0]
      .setColor("RANDOM")
      .setTitle("__SUGGESTION APPROUVER__")
      .setTimestamp();

    if (approvedEmbed.fields.length > 0) {
      approvedEmbed.fields[0].name = "Approuvé par";
      approvedEmbed.fields[0].value = `${member.user.tag} [${member.id}]`;
    } else {
      const [upVotes, downVotes] = getStats(message);

      doc.stats.upvotes = upVotes;
      doc.stats.downvotes = downVotes;

      approvedEmbed.addField("Approuvé par", `${member.user.tag} [${member.id}]`).setFooter({
        text: `Stats: ${SUGGESTIONS.EMOJI.UP_VOTE} ${upVotes} ${SUGGESTIONS.EMOJI.DOWN_VOTE} ${downVotes}`,
      });
    }

    try {
      doc.status = "APPROVED";
      doc.status_updates.push({ user_id: member.id, status: "APPROVED", timestamp: new Date() });
      await doc.save();

      await message.edit({ embeds: [approvedEmbed], components: [buttonsRow] });
      await message.reactions.removeAll();

      return true;
    } catch (ex) {
      guild.client.logger.error("approveSuggestion", ex);
      return "Impossible d'approuver la suggestion";
    }
  },

  /**
   * @param {import('discord.js').Guild} guild
   * @param {import('discord.js').GuildMember} member
   * @param {string} messageId
   */
  async rejectSuggestion(guild, member, messageId) {
    // validate document
    const doc = await findSuggestion(guild.id, messageId);
    if (!doc) return "Suggestion non trouvée";
    if (doc.is_rejected) return "Suggestion déjà rejetée";

    // validate channel
    const settings = await getSettings(guild);
    if (!settings.suggestions.channel_id) return "Suggestions salon non définies";
    const suggestionsChannel = guild.channels.cache.get(settings.suggestions.channel_id);
    if (!suggestionsChannel) return "Suggestions salon introuvable";

    let message;
    try {
      message = await suggestionsChannel.messages.fetch(messageId);
    } catch (err) {
      return "Message de Suggestion non trouvé";
    }

    let buttonsRow = new MessageActionRow().addComponents(
      new MessageButton().setCustomId("SUGGEST_APPROVE").setLabel("Approuver").setStyle("SUCCESS"),
      new MessageButton().setCustomId("SUGGEST_REJECT").setLabel("Rejeter").setStyle("DANGER").setDisabled(true)
    );

    const rejectedEmbed = message.embeds[0]
      .setColor("RANDOM")
      .setTitle("__SUGGESTION REJETER__")
      .setTimestamp();

    if (rejectedEmbed.fields.length > 0) {
      rejectedEmbed.fields[0].name = "Rejeté par";
      rejectedEmbed.fields[0].value = `${member.user.tag} [${member.id}]`;
    } else {
      const [upVotes, downVotes] = getStats(message);

      doc.stats.upvotes = upVotes;
      doc.stats.downvotes = downVotes;

      rejectedEmbed.addField("Rejeté par", `${member.user.tag} [${member.id}]`).setFooter({
        text: `Stats: ${SUGGESTIONS.EMOJI.UP_VOTE} ${upVotes} ${SUGGESTIONS.EMOJI.DOWN_VOTE} ${downVotes}`,
      });
    }

    try {
      doc.status = "REJECTED";
      doc.status_updates.push({ user_id: member.id, status: "REJECTED", timestamp: new Date() });
      await doc.save();

      await message.edit({ embeds: [rejectedEmbed], components: [buttonsRow] });
      await message.reactions.removeAll();

      return true;
    } catch (ex) {
      guild.client.logger.error("rejectSuggestion", ex);
      return "Échoué à rejeter la suggestion";
    }
  },
};
