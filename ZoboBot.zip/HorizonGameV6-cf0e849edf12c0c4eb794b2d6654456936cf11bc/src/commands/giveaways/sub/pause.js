/**
 * @param {import('discord.js').GuildMember} member
 * @param {string} messageId
 */
module.exports = async (member, messageId) => {
  if (!messageId) return "Vous devez fournir un identifiant de message valide.";

  // Permissions
  if (!member.permissions.has("MANAGE_MESSAGES")) {
    return "Vous devez disposer des autorisations de gestion des messages pour gérer les giveaways.";
  }

  // Search with messageId
  const giveaway = member.client.giveawaysManager.giveaways.find(
    (g) => g.messageId === messageId && g.guildId === member.guild.id
  );

  // If no giveaway was found
  if (!giveaway) return `Impossible de trouver un giveaway pour messageId : ${messageId}`;

  // Check if the giveaway is paused
  if (giveaway.pauseOptions.isPaused) return "Ce giveaway est déjà en pause.";

  try {
    await giveaway.pause();
    return "Succès! giveaway en pause !";
  } catch (error) {
    member.client.logger.error("Giveaway en pause", error);
    return `Une erreur s'est produite lors de la suspension du Giveaway : ${error.message}`;
  }
};
