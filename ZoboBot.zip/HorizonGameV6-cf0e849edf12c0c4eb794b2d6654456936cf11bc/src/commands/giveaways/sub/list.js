const { EMBED_COLORS } = require("@root/config");

/**
 * @param {import('discord.js').GuildMember} member
 */
module.exports = async (member) => {
  // Permissions
  if (!member.permissions.has("MANAGE_MESSAGES")) {
    return "Vous devez disposer des autorisations de gestion des messages pour gérer les giveaways.";
  }

  // Search with all giveaways
  const giveaways = member.client.giveawaysManager.giveaways.filter(
    (g) => g.guildId === member.guild.id && g.ended === false
  );

  // No giveaways
  if (giveaways.length === 0) {
    return "Il n'y a pas de giveaway en cours d'exécution sur ce serveur.";
  }

  const description = giveaways.map((g, i) => `${i + 1}. ${g.prize} dans <#${g.channelId}>`).join("\n");

  try {
    return { embeds: [{ description, color: EMBED_COLORS.GIVEAWAYS }] };
  } catch (error) {
    member.client.logger.error("Liste de giveaways", error);
    return `Une erreur s'est produite lors de la liste des giveaways: ${error.message}`;
  }
};
