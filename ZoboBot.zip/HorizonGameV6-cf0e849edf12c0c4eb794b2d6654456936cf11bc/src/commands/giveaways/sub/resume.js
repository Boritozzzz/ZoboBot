/**
 * @param {import('discord.js').GuildMember} member
 * @param {string} messageId
 */
module.exports = async (member, messageId) => {
  if (!messageId) return "Vous devez fournir un identifiant de message valide.";

  // Permissions
  if (!member.permissions.has("MANAGE_MESSAGES")) {
    return "Vous devez disposer des autorisations de gestion des messages pour gérer les giveaways.";
  }

  // Search with messageId
  const giveaway = member.client.giveawaysManager.giveaways.find(
    (g) => g.messageId === messageId && g.guildId === member.guild.id
  );

  // If no giveaway was found
  if (!giveaway) return `Impossible de trouver un giveaway pour messageId: ${messageId}`;

  // Check if the giveaway is unpaused
  if (!giveaway.pauseOptions.isPaused) return "Ce giveaway n'est pas en pause.";

  try {
    await giveaway.unpause();
    return "Succès! giveaway non interrompu !";
  } catch (error) {
    member.client.logger.error("Réactivation du giveaway", error);
    return `Une erreur s'est produite lors de la réactivation du giveaway: ${error.message}`;
  }
};
