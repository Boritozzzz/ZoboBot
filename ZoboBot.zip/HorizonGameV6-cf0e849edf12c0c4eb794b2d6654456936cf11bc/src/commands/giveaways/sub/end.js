/**
 * @param {import('discord.js').GuildMember} member
 * @param {string} messageId
 */
module.exports = async (member, messageId) => {
  if (!messageId) return "Vous devez fournir un identifiant de message valide.";

  // Permissions
  if (!member.permissions.has("MANAGE_MESSAGES")) {
    return "Vous devez disposer des autorisations de gestion des messages pour lancer des giveaways.";
  }

  // Search with messageId
  const giveaway = member.client.giveawaysManager.giveaways.find(
    (g) => g.messageId === messageId && g.guildId === member.guild.id
  );

  // If no giveaway was found
  if (!giveaway) return `Impossible de trouver un giveaway pour messageId : ${messageId}`;

  // Check if the giveaway is ended
  if (giveaway.ended) return "Le giveaway est déjà terminé.";

  try {
    await giveaway.end();
    return "Succès! Le giveaway est terminé !";
  } catch (error) {
    member.client.logger.error("Fin du cadeau", error);
    return `Une erreur s'est produite lors de la fin du giveaway: ${error.message}`;
  }
};
