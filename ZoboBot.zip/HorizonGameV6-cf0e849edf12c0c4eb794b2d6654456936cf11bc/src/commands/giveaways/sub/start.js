/**
 * @param {import('discord.js').GuildMember} member
 * @param {import('discord.js').GuildTextBasedChannel} giveawayChannel
 * @param {number} duration
 * @param {string} prize
 * @param {number} winners
 * @param {import('discord.js').User} host
 */
module.exports = async (member, giveawayChannel, duration, prize, winners, host) => {
  if (!member.permissions.has("MANAGE_MESSAGES")) {
    return "Vous devez disposer des autorisations de gestion des messages pour lancer des giveaways.";
  }

  if (!giveawayChannel.isText()) {
    return "Vous ne pouvez lancer des giveaways que dans les salons textuel.";
  }

  try {
    await member.client.giveawaysManager.start(giveawayChannel, {
      duration: 60000 * duration,
      prize,
      winnerCount: winners,
      hostedBy: host,
      thumbnail: "https://images-ext-1.discordapp.net/external/MVydLaGG7T8f1fqYUe83N0v9GetXiVCmOmSc5XLSkwQ/https/emoji.gg/assets/emoji/3544-giveaway.gif",
      color: "RANDOM",
      messages: {
        giveaway: "🎉 **__GIVEAWAY__** 🎉",
        giveawayEnded: "🎉 **__GIVEAWAY TERMINÉ__** 🎉",
        inviteToParticipate: "Réagissez avec <:giveawaysssa:885090857747877939> pour particper!",
        dropMessage: "Soyez le premier à réagir avec <:giveawaysssa:885090857747877939> pour gagner!",
        hostedBy: `<:emoji_44:885169331976163328>__**Hosted par**__: ${host}`,
      },
    });

    return `Le giveaway a commencé dans ${giveawayChannel}`;
  } catch (error) {
    member.client.logger.error("Début du giveaway", error);
    return `Une erreur s'est produite lors du démarrage du giveaway: ${error.message}`;
  }
};
