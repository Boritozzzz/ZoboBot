const { Command } = require("@src/structures");
const { Message, MessageEmbed, CommandInteraction, MessageActionRow, MessageSelectMenu } = require("discord.js");
const prettyMs = require("pretty-ms");
const { EMBED_COLORS } = require("@root/config");

module.exports = class Search extends Command {
  constructor(client) {
    super(client, {
      name: "search",
      description: "rechercher des chansons correspondantes sur youtube",
      category: "MUSIC",
      botPermissions: ["EMBED_LINKS"],
      command: {
        enabled: true,
        usage: "<titre de chanson>",
        minArgsCount: 1,
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "query",
            description: "chanson à rechercher",
            type: "STRING",
            required: true,
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   */
  async messageRun(message, args) {
    const query = args.join(" ");
    const response = await search(message, message.author, query);
    if (response) await message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   */
  async interactionRun(interaction) {
    const query = interaction.options.getString("query");
    const response = await search(interaction, interaction.user, query);
    if (response) await interaction.followUp(response);
    else interaction.deleteReply();
  }
};

async function search({ member, guild, channel }, user, query) {
  if (!member.voice.channel) return "<:emoji_17:885086787700154388> Vous devez d'abord rejoindre un salon vocal";
  let player = guild.client.musicManager.get(guild.id);

  if (player && member.voice.channel !== guild.me.voice.channel) {
    return "<:emoji_17:885086787700154388> Vous devez être dans le même salon vocal que le mien";
  }

  try {
    player = guild.client.musicManager.create({
      guild: guild.id,
      textChannel: channel.id,
      voiceChannel: member.voice.channel.id,
      volume: 50,
    });
  } catch (ex) {
    if (ex.message === "Aucun nodes disponible.") {
      guild.client.logger.debug("Aucun nodes disponible!");
      return "<:emoji_17:885086787700154388> Aucun nodes disponible ! Réessayez plus tard";
    }
  }

  if (player.state !== "CONNECTED") player.connect();
  let res;

  try {
    res = await player.search(query, user);
    if (res.loadType === "LOAD_FAILED") {
      if (!player.queue.current) player.destroy();
      throw new Error(res.exception.message);
    }
  } catch (err) {
    guild.client.logger.error("Erreur de recherche", err);
    return "Une erreur s'est produite lors de la recherche";
  }

  let embed = new MessageEmbed().setColor(EMBED_COLORS.BOT_EMBED);
  let track;

  switch (res.loadType) {
    case "NO_MATCHES":
      if (!player.queue.current) player.destroy();
      return `Aucun résultat trouvé correspondant ${query}`;

    case "TRACK_LOADED":
      track = res.tracks[0];
      player.queue.add(track);
      if (!player.playing && !player.paused && !player.queue.size) {
        player.play();
        return "> <:musicccc:885078247954595870> Musique ajouter à la file d'attente";
      }

      embed
        .setThumbnail(track.displayThumbnail("hqdefault"))
        .setTitle("<a:horizongame_cd:946880912803651645>__MUSIQUE AJOUTER__")
    .setTimestamp()
        .setDescription(`[${track.title}](${track.uri})`)
        .addField("<:horlo:885097507699429376>__Durée__", "`" + prettyMs(track.duration, { colonNotation: true }) + "`", true)
        .setFooter({ text: `Ajouté par: ${track.requester.tag}` });

      if (player.queue.totalSize > 0) embed.addField("__<:animeeee:885087722828611625>Position__", (player.queue.size - 0).toString(), true);
      return { embeds: [embed] };

    case "PLAYLIST_LOADED":
      player.queue.add(res.tracks);
      if (!player.playing && !player.paused && player.queue.totalSize === res.tracks.length) {
        player.play();
      }

      embed
        .setTitle("<a:horizongame_cd:946880912803651645>__MUSIQUE AJOUTER__")
    .setTimestamp()
        .setDescription(res.playlist.name)
        .addField("Enqueued", `${res.tracks.length} songs`, true)
        .addField("<:horlo:885097507699429376>__Durée__", "`" + prettyMs(res.playlist.duration, { colonNotation: true }) + "`", true)
        .setFooter({ text: `Ajouté par: ${res.tracks[0].requester.tag}` });

      return { embeds: [embed] };

    case "SEARCH_RESULT": {
      let max = guild.client.config.MUSIC.MAX_SEARCH_RESULTS;
      if (res.tracks.length < max) max = res.tracks.length;

      const results = res.tracks.slice(0, max);
      const options = results.map((result, index) => ({
        label: result.title,
        value: index.toString(),
      }));

      const menuRow = new MessageActionRow().addComponents(
        new MessageSelectMenu()
          .setCustomId("search-results")
          .setPlaceholder("Choisissez les résultats de la recherche")
          .setMaxValues(max)
          .addOptions(options)
      );

      embed.setAuthor({ name: "Résultats de recherche" }).setDescription(`Veuillez sélectionner les chansons que vous souhaitez ajouter à la file d'attente`);

      const sentMsg = await channel.send({
        embeds: [embed],
        components: [menuRow],
      });

      const collector = channel.createMessageComponentCollector({
        filter: (reactor) => reactor.user.id === user.id,
        idle: 30 * 1000,
        dispose: true,
      });

      collector.on("collect", async (response) => {
        if (response.customId !== "search-results") return;
        const toAdd = [];
        response.values.forEach((v) => toAdd.push(results[v]));

        // Only 1 song is selected
        if (toAdd.length === 1) {
          track = toAdd[0];

          player.queue.add(track);
          if (!player.playing && !player.paused && !player.queue.size) {
            await sentMsg.edit({
              content: "> <:musicccc:885078247954595870> Musique ajouter à la file d'attente",
              embeds: [],
              components: [],
            });
            return player.play();
          }

          embed
             .setThumbnail(track.displayThumbnail("hqdefault"))
        .setTitle("<a:horizongame_cd:946880912803651645>__MUSIQUE AJOUTER__")
    .setTimestamp()
        .setDescription(`[${track.title}](${track.uri})`)
        .addField("<:horlo:885097507699429376>__Durée__", "`" + prettyMs(track.duration, { colonNotation: true }) + "`", true)
        .setFooter({ text: `Ajouté par: ${track.requester.tag}` });

          if (player.queue.totalSize > 0) embed.addField("__<:animeeee:885087722828611625>Position__", (player.queue.size - 0).toString(), true);

          return sentMsg.edit({ embeds: [embed], components: [] });
        }

        // Multiple songs were selected
        player.queue.add(toAdd);
        if (!player.playing && !player.paused && player.queue.totalSize === toAdd.length) {
          player.play();
        }

        embed
          .setDescription(`<a:horizongame_cd:946880912803651645>Ajouté ${toAdd.length} chansons à mettre en file d'attente`)
          .setFooter({ text: `Ajouté par: ${res.tracks[0].requester.tag}` });

        return sentMsg.edit({ embeds: [embed], components: [] });
      });

      collector.on("end", () => sentMsg.edit({ components: [] }));
    }
  }
}