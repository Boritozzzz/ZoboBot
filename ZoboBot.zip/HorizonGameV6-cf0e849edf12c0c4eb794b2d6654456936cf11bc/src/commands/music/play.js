const { Command } = require("@src/structures");
const { Message, MessageEmbed, CommandInteraction } = require("discord.js");
const prettyMs = require("pretty-ms");
const { EMBED_COLORS } = require("@root/config");

module.exports = class Play extends Command {
  constructor(client) {
    super(client, {
      name: "play",
      description: "jouer une chanson de youtube ou d'une autre platforme",
      category: "MUSIC",
      botPermissions: ["EMBED_LINKS"],
      command: {
        enabled: true,
        aliases: ["p"],
        usage: "<titre de chanson>",
        minArgsCount: 1,
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "query",
            description: "nom ou URL de la chanson",
            type: "STRING",
            required: true,
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   */
  async messageRun(message, args) {
    const query = args.join(" ");
    const response = await play(message, message.author, query);
    await message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   */
  async interactionRun(interaction) {
    const query = interaction.options.getString("query");
    const response = await play(interaction, interaction.user, query);
    await interaction.followUp(response);
  }
};

async function play({ member, guild, channel }, user, query) {
  if (!member.voice.channel) return "<:emoji_17:885086787700154388> Vous devez d'abord rejoindre un salon vocal";
  let player = guild.client.musicManager.get(guild.id);

  if (player && member.voice.channel !== guild.me.voice.channel) {
    return "<:emoji_17:885086787700154388> Vous devez être dans le même salon vocal que le mien";
  }

  try {
    player = guild.client.musicManager.create({
      guild: guild.id,
      textChannel: channel.id,
      voiceChannel: member.voice.channel.id,
      volume: 50,
    });
  } catch (ex) {
    if (ex.message === "Aucun nodes disponible.") {
      guild.client.logger.debug("Aucun nodes disponible !");
      return "<:emoji_17:885086787700154388> Aucun nodes disponible ! Réessayez plus tard";
    }
  }

  if (player.state !== "CONNECTED") player.connect();
  let res;

  try {
    res = await player.search(query, user);
    if (res.loadType === "LOAD_FAILED") {
      if (!player.queue.current) player.destroy();
      throw res.exception;
    }
  } catch (err) {
    guild.client.logger.error("Erreur de recherche", err);
    return "Une erreur s'est produite lors de la recherche";
  }

  let embed = new MessageEmbed().setColor(EMBED_COLORS.BOT_EMBED);
  let track;

  switch (res.loadType) {
    case "NO_MATCHES":
      if (!player.queue.current) player.destroy();
      return `Aucun résultat trouvé correspondant ${query}`;

    case "TRACK_LOADED":
      track = res.tracks[0];
      player.queue.add(track);
      if (!player.playing && !player.paused && !player.queue.size) {
        player.play();
        return "> <:musicccc:885078247954595870> Musique ajouter à la file d'attente";
      }

      embed
        .setTitle("<a:horizongame_cd:946880912803651645>__MUSIQUE AJOUTER__")
    .setTimestamp()
        .setDescription(`[${track.title}](${track.uri})`)
        .addField("<:horlo:885097507699429376>__Durée__", "`" + prettyMs(track.duration, { colonNotation: true }) + "`", true)
        .setFooter({ text: `Ajouté par: ${track.requester.tag}` });

      if (typeof track.displayThumbnail === "function") embed.setThumbnail(track.displayThumbnail("hqdefault"));
      if (player.queue.totalSize > 0) embed.addField("__<:animeeee:885087722828611625>Position__", (player.queue.size - 0).toString(), true);
      return { embeds: [embed] };

    case "PLAYLIST_LOADED":
      player.queue.add(res.tracks);
      if (!player.playing && !player.paused && player.queue.totalSize === res.tracks.length) {
        player.play();
      }

      embed
        .setTitle("<a:horizongame_cd:946880912803651645>__MUSIQUE AJOUTER__")
        .setTimestamp()
        .setDescription(res.playlist.name)
        .addField("__En file d'attente__", `${res.tracks.length} songs`, true)
        .addField("<:horlo:885097507699429376>__Durée__", "`" + prettyMs(res.playlist.duration, { colonNotation: true }) + "`", true)
        .setFooter({ text: `Ajouté par: ${res.tracks[0].requester.tag}` });

      return { embeds: [embed] };

    case "SEARCH_RESULT":
      track = res.tracks[0];
      player.queue.add(track);
      if (!player.playing && !player.paused && !player.queue.size) {
        player.play();
        return "> <:musicccc:885078247954595870> Musique ajouter à la file d'attente";
      }

      embed
         .setTitle("<a:horizongame_cd:946880912803651645>__MUSIQUE AJOUTER__")
        .setTimestamp()
        .setDescription(`[${track.title}](${track.uri})`)
        .addField("<:horlo:885097507699429376>__Durée__", "`" + prettyMs(track.duration, { colonNotation: true }) + "`", true)
        .setFooter({ text: `Ajouté par: ${track.requester.tag}` });

      if (player.queue.totalSize > 0) embed.addField("__<:animeeee:885087722828611625>Position__", (player.queue.size - 0).toString(), true);
      return { embeds: [embed] };
  }
}
