const { MessageEmbed, Message, MessageActionRow, MessageButton, CommandInteraction } = require("discord.js");
const { Command } = require("@src/structures");
const { EMBED_COLORS } = require("@root/config.js");

// Schemas
const { createNewTicket } = require("@schemas/Message");

// Utils
const { parsePermissions, canSendEmbeds } = require("@utils/botUtils");
const { isTicketChannel, closeTicket, closeAllTickets } = require("@utils/ticketUtils");
const { isHex } = require("@utils/miscUtils");

const SETUP_TIMEOUT = 30 * 1000;

const SETUP_PERMS = ["VIEW_CHANNEL", "SEND_MESSAGES", "EMBED_LINKS"];

module.exports = class Ticket extends Command {
  constructor(client) {
    super(client, {
      name: "ticket",
      description: "diverses commandes de ticket",
      category: "TICKET",
      userPermissions: ["MANAGE_GUILD"],
      command: {
        enabled: true,
        minArgsCount: 1,
        subcommands: [
          {
            trigger: "setup",
            description: "démarrer une configuration de ticket interactif",
          },
          {
            trigger: "log <#channel>",
            description: "configurer le salon de log pour les tickets",
          },
          {
            trigger: "limit <number>",
            description: "définir le nombre maximum de tickets ouverts simultanés",
          },
          {
            trigger: "close",
            description: "fermer le ticket",
          },
          {
            trigger: "closeall",
            description: "fermer tous les tickets ouverts",
          },
          {
            trigger: "add <userId|roleId>",
            description: "ajouter un utilisateur/rôle au ticket",
          },
          {
            trigger: "remove <userId|roleId>",
            description: "supprimer l'utilisateur/le rôle du ticket",
          },
        ],
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "setup",
            description: "configurer un nouveau message de ticket",
            type: "SUB_COMMAND",
            options: [
              {
                name: "channel",
                description: "le salon où le message de création de ticket doit être envoyé",
                type: "CHANNEL",
                channelTypes: ["GUILD_TEXT"],
                required: true,
              },
              {
                name: "title",
                description: "le titre du message du ticket",
                type: "STRING",
                required: true,
              },
              {
                name: "role",
                description: "les rôles qui peuvent avoir accès aux tickets nouvellement ouverts",
                type: "ROLE",
                required: false,
              },
              {
                name: "color",
                description: "couleur hexadécimale pour l'intégration du ticket",
                type: "STRING",
                required: false,
              },
            ],
          },
          {
            name: "log",
            description: "configurer le salon de log pour les tickets",
            type: "SUB_COMMAND",
            options: [
              {
                name: "channel",
                description: "salon où les logs de tickets doivent être envoyés",
                type: "CHANNEL",
                channelTypes: ["GUILD_TEXT"],
                required: true,
              },
            ],
          },
          {
            name: "limit",
            description: "définir le nombre maximum de tickets ouverts simultanés",
            type: "SUB_COMMAND",
            options: [
              {
                name: "amount",
                description: "nombre maximum de tickets",
                type: "INTEGER",
                required: true,
              },
            ],
          },
          {
            name: "close",
            description: "ferme le ticket [utilisé uniquement dans le salon de tickets]",
            type: "SUB_COMMAND",
          },
          {
            name: "closeall",
            description: "ferme tous les tickets ouverts",
            type: "SUB_COMMAND",
          },
          {
            name: "add",
            description: "ajouter un utilisateur au salon de tickets actuel [utilisé uniquement dans le salon de tickets]",
            type: "SUB_COMMAND",
            options: [
              {
                name: "user_id",
                description: "l'identifiant de l'utilisateur à ajouter",
                type: "STRING",
                required: true,
              },
            ],
          },
          {
            name: "remove",
            description: "supprimer l'utilisateur du salon de tickets [utilisé uniquement dans le salon de tickets]",
            type: "SUB_COMMAND",
            options: [
              {
                name: "user",
                description: "l'utilisateur à supprimer",
                type: "USER",
                required: true,
              },
            ],
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   * @param {object} data
   */
  async messageRun(message, args, data) {
    const input = args[0].toLowerCase();
    let response;

    // Setup
    if (input === "setup") {
      if (!message.guild.me.permissions.has("MANAGE_CHANNELS")) {
        return message.reply("Il me manque la permission de `Gérer les salons` pour créer des salons de tickets");
      }
      return runInteractiveSetup(message);
    }

    // log ticket
    else if (input === "log") {
      if (args.length < 2) return message.reply("Veuillez fournir un salon où les logs de tickets doivent être envoyés");
      const target = message.guild.findMatchingChannels(args[1]);
      if (target.length === 0) return message.reply("Impossible de trouver le salon correspondante");
      response = await setupLogChannel(target[0], data.settings);
    }

    // Set limit
    else if (input === "limit") {
      if (args.length < 2) return message.reply("Veuillez fournir un nombre");
      const limit = args[1];
      if (isNaN(limit)) return message.reply("Veuillez saisir un nombre");
      response = await setupLimit(message, limit, data.settings);
    }

    // Close ticket
    else if (input === "close") {
      response = await close(message, message.author);
      if (!response) return;
    }

    // Close all tickets
    else if (input === "closeall") {
      let sent = await message.reply("Fermeture du ticket...");
      response = await closeAll(message);
      return sent.editable ? sent.edit(response) : message.channel.send(response);
    }

    // Add user to ticket
    else if (input === "add") {
      if (args.length < 2) return message.reply("Veuillez fournir un utilisateur ou un rôle à ajouter au ticket");
      let inputId;
      if (message.mentions.users.size > 0) inputId = message.mentions.users.first().id;
      else if (message.mentions.roles.size > 0) inputId = message.mentions.roles.first().id;
      else inputId = args[1];
      response = await addToTicket(message, inputId);
    }

    // Remove user from ticket
    else if (input === "remove") {
      if (args.length < 2) return message.reply("Veuillez fournir un utilisateur ou un rôle à supprimer");
      let inputId;
      if (message.mentions.users.size > 0) inputId = message.mentions.users.first().id;
      else if (message.mentions.roles.size > 0) inputId = message.mentions.roles.first().id;
      else inputId = args[1];
      response = await removeFromTicket(message, inputId);
    }

    // Invalid input
    else {
      return message.reply("Utilisation incorrecte de la commande");
    }

    if (response) await message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   * @param {object} data
   */
  async interactionRun(interaction, data) {
    const sub = interaction.options.getSubcommand();
    let response;

    // setup
    if (sub === "setup") {
      const channel = interaction.options.getChannel("channel");
      const title = interaction.options.getString("title");
      const role = interaction.options.getRole("role");
      const color = interaction.options.getString("color");

      if (!interaction.guild.me.permissions.has("MANAGE_CHANNELS")) {
        return interaction.followUp("Il me manque la permission de `Gérer les salons` pour créer des salons de tickets");
      }

      if (color && !isHex(color)) return interaction.followUp("Veuillez fournir une couleur hexadécimale valide");
      if (role && (role.managed || interaction.guild.me.roles.highest.position < role.position)) {
        return interaction.followUp("Je n'ai pas les autorisations pour gérer ce rôle");
      }

      if (!canSendEmbeds(channel)) {
        return interaction.followUp(`Je n'ai pas besoin d'autorisations pour envoyer des intégrations dans ${channel}`);
      }

      response = await setupTicket(interaction.guild, channel, title, role, color);
    }

    // Log channel
    else if (sub === "log") {
      const channel = interaction.options.getChannel("channel");
      response = await setupLogChannel(channel, data.settings);
    }

    // Limit
    else if (sub === "limit") {
      const limit = interaction.options.getInteger("amount");
      response = await setupLimit(interaction, limit, data.settings);
    }

    // Close
    else if (sub === "close") {
      response = await close(interaction, interaction.user);
    }

    // Close all
    else if (sub === "closeall") {
      response = await closeAll(interaction);
    }

    // Add to ticket
    else if (sub === "add") {
      const inputId = interaction.options.getString("user_id");
      response = await addToTicket(interaction, inputId);
    }

    // Remove from ticket
    else if (sub === "remove") {
      const user = interaction.options.getUser("user");
      response = await removeFromTicket(interaction, user.id);
    }

    if (response) await interaction.followUp(response);
  }
};

/**
 * @param {Message} message
 */
async function runInteractiveSetup({ channel, guild, author }) {
  const filter = (m) => m.author.id === author.id;

  const embed = new MessageEmbed()
    .setAuthor({ name: "Configuration du ticket" })
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setFooter({ text: "Tapez cancel pour annuler la configuration" });

  let targetChannel;
  let title;
  let role;
  try {
    // wait for channel
    await channel.send({
      embeds: [embed.setDescription("Veuillez `mentionner le salon` dans lequel le message de ticket doit être envoyé")],
    });
    let reply = (await channel.awaitMessages({ filter, max: 1, time: SETUP_TIMEOUT })).first();
    if (reply.content.toLowerCase() === "cancel") return reply.reply("La configuration du ticket a été annulée");
    targetChannel = reply.mentions.channels.first();
    if (!targetChannel) return reply.reply("La configuration du ticket a été annulée. Vous n'avez pas mentionné de salon");
    if (!targetChannel.isText() && !targetChannel.permissionsFor(guild.me).has(SETUP_PERMS)) {
      return reply.reply(
        `La configuration du ticket a été annulée.\nj'ai besoin des permissions ${parsePermissions(SETUP_PERMS)} in ${targetChannel}`
      );
    }

    // wait for title
    await channel.send({ embeds: [embed.setDescription("Veuillez entrer le `titre` du ticket")] });
    reply = (await channel.awaitMessages({ filter, max: 1, time: SETUP_TIMEOUT })).first();
    if (reply.content.toLowerCase() === "cancel") return reply.reply("La configuration du ticket a été annulée");
    title = reply.content;

    // wait for roles
    const desc =
      "Quels rôles doivent avoir accès pour voir les tickets nouvellement créés ?\n" +
      "Veuillez saisir le nom d'un rôle existant sur ce serveur.\n\n" +
      "Sinon, vous pouvez taper `none`";

    await channel.send({ embeds: [embed.setDescription(desc)] });
    reply = (await channel.awaitMessages({ filter, max: 1, time: SETUP_TIMEOUT })).first();
    const query = reply.content.toLowerCase();

    if (query === "cancel") return reply.reply("La configuration du ticket a été annulée");
    if (query !== "none") {
      const roles = guild.findMatchingRoles(query);
      if (roles.length === 0) {
        return reply.reply(`Uh oh, je n'ai trouvé aucun rôle appelé ${query}! La configuration du ticket a été annulée`);
      }
      role = roles[0];
      if (role.managed || guild.me.roles.highest.position < role.position) {
        return reply.reply("La configuration du ticket a été annulée. Je n'ai pas la permission de gérer ce rôle");
      }
      await reply.reply(`Nice! \`${role.name}\` peut maintenant voir les tickets nouvellement créés`);
    }
  } catch (ex) {
    return channel.send("Pas de réponse depuis 30 secondes, la configuration a été annulée");
  }

  const response = await setupTicket(guild, targetChannel, title, role);
  return channel.send(response);
}

async function setupTicket(guild, channel, title, role, color) {
  try {
    const embed = new MessageEmbed()
      .setColor("RANDOM")
      .setDescription(title)
      .setFooter({ text: "Vous ne pouvez avoir qu'un seul ticket ouvert à la fois !" });

    if (color) embed.setColor(color);

    const row = new MessageActionRow().addComponents(
      new MessageButton().setLabel("📩").setCustomId("TICKET_CREATE").setStyle("SUCCESS")
    );

    const tktMessage = await channel.send({ embeds: [embed], components: [row] });

    // save to Database
    await createNewTicket(guild.id, channel.id, tktMessage.id, title, role?.id);

    // send success
    return "Configuration enregistrée ! Le message du ticket est maintenant configuré 🎉";
  } catch (ex) {
    guild.client.logger.error("ticketSetup", ex);
    return "Une erreur inattendue s'est produite! La configuration a échoué";
  }
}

async function setupLogChannel(target, settings) {
  if (!canSendEmbeds(target)) return `Oups! J'ai l'autorisation d'envoyer une intégration à ${target}`;

  settings.ticket.log_channel = target.id;
  await settings.save();

  return `Configuration enregistrée ! Les logs de tickets seront envoyés à ${target.toString()}`;
}

async function setupLimit(limit, settings) {
  if (Number.parseInt(limit, 10) < 5) return "Tla limite de ticket ne peut pas être inférieure à 5";

  settings.ticket.limit = limit;
  await settings.save();

  return `Configuration enregistrée. Vous pouvez maintenant avoir un maximum de \`${limit}\` tickets ouverts`;
}

async function close({ channel }, author) {
  if (!isTicketChannel(channel)) return "Cette commande ne peut être utilisée que dans les salons de tickets";
  const status = await closeTicket(channel, author, "Fermé par un modérateur");
  if (status === "MISSING_PERMISSIONS") return "Je n'ai pas la permission de fermer les tickets";
  if (status === "ERROR") return "Une erreur s'est produite lors de la fermeture du ticket";
  return null;
}

async function closeAll({ guild }) {
  const stats = await closeAllTickets(guild);
  return `Complété! Succès: \`${stats[0]}\` Échoué: \`${stats[1]}\``;
}

async function addToTicket({ channel }, inputId) {
  if (!isTicketChannel(channel)) return "Cette commande ne peut être utilisée que dans le salon de ticket";
  if (!inputId || isNaN(inputId)) return "Oups! Vous devez entrer un valide userId/roleId";

  try {
    await channel.permissionOverwrites.create(inputId, {
      VIEW_CHANNEL: true,
      SEND_MESSAGES: true,
    });

    return "Done";
  } catch (ex) {
    return "Échec de l'ajout de l'utilisateur/du rôle. Avez-vous fourni un id valide ?";
  }
}

async function removeFromTicket({ channel }, inputId) {
  if (!isTicketChannel(channel)) return "Cette commande ne peut être utilisée que dans le salon de ticket";
  if (!inputId || isNaN(inputId)) return "Oups! Vous devez entrer un valide userId/roleId";

  try {
    channel.permissionOverwrites.create(inputId, {
      VIEW_CHANNEL: false,
      SEND_MESSAGES: false,
    });
    return "Done";
  } catch (ex) {
    return "Échec de la suppression de l'utilisateur/du rôle. Avez-vous fourni un id valide ?";
  }
}
