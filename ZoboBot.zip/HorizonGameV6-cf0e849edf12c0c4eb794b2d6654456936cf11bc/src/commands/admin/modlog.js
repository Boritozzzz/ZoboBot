const { Command } = require("@src/structures");
const { Message, CommandInteraction } = require("discord.js");
const { canSendEmbeds } = require("@utils/botUtils");

module.exports = class ModLog extends Command {
  constructor(client) {
    super(client, {
      name: "modlog",
      description: "activer ou désactiver les logs de modération",
      category: "ADMIN",
      userPermissions: ["MANAGE_GUILD"],
      command: {
        enabled: true,
        usage: "<#channel|off>",
        minArgsCount: 1,
      },
      slashCommand: {
        enabled: true,
        ephemeral: true,
        options: [
          {
            name: "channel",
            description: "salon pour envoyer les logs de mod",
            required: false,
            type: "CHANNEL",
            channelTypes: ["GUILD_TEXT"],
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   * @param {object} data
   */
  async messageRun(message, args, data) {
    const input = args[0].toLowerCase();
    let targetChannel;

    if (input === "none" || input === "off" || input === "disable") targetChannel = null;
    else {
      if (message.mentions.channels.size === 0) return message.reply("Utilisation incorrecte de la commande");
      targetChannel = message.mentions.channels.first();
    }

    const response = await setChannel(targetChannel, data.settings);
    return message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   * @param {object} data
   */
  async interactionRun(interaction, data) {
    const response = await setChannel(interaction.options.getChannel("channel"), data.settings);
    return interaction.followUp(response);
  }
};

async function setChannel(targetChannel, settings) {
  if (targetChannel) {
    if (!canSendEmbeds(targetChannel))
      return "Pouah! Je ne peux pas envoyer de log dans ce salon ? J'ai besoin des autorisations `Write Messages` et `Embed Links` dans ce salon";
  }

  settings.modlog_channel = targetChannel?.id;
  await settings.save();
  return `Configuration enregistrée ! salon Modlog ${targetChannel ? "updated" : "removed"}`;
}