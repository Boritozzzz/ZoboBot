const { Command } = require("@src/structures");
const { Message, CommandInteraction } = require("discord.js");

module.exports = class Automod extends Command {
  constructor(client) {
    super(client, {
      name: "automod",
      description: "diverses configurations d'automod",
      category: "AUTOMOD",
      userPermissions: ["MANAGE_GUILD"],
      command: {
        enabled: true,
        minArgsCount: 2,
        subcommands: [
          {
            trigger: "antighostping <ON|OFF>",
            description: "Enregistre les mentions fantômes sur votre serveur",
          },
          {
            trigger: "antiinvites <ON|OFF>",
            description: "Autoriser ou interdire l'envoi d'invitations discord dans le message",
          },
          {
            trigger: "antilinks <ON|OFF>",
            description: "Autoriser ou interdire l'envoi de liens dans le message",
          },
          {
            trigger: "antiscam <ON|OFF>",
            description: "Activer ou désactiver la détection anti-scam",
          },
          {
            trigger: "maxlines <numéro>",
            description: "Définit le nombre maximum de lignes autorisées par message [0 pour désactiver]",
          },
          {
            trigger: "maxmentions <numéro>",
            description: "Définit le nombre maximal de mentions de membres autorisées par message [0 pour désactiver]",
          },
          {
            trigger: "maxrolementions <numéro>",
            description: "Définit le nombre maximal de mentions de rôle autorisées par message [0 pour désactiver]",
          },
        ],
      },
      slashCommand: {
        enabled: true,
        ephemeral: true,
        options: [
          {
            name: "antighostping",
            description: "Enregistre les mentions fantômes sur votre serveur",
            type: "SUB_COMMAND",
            options: [
              {
                name: "status",
                description: "état de la configuration",
                required: true,
                type: "STRING",
                choices: [
                  {
                    name: "ON",
                    value: "ON",
                  },
                  {
                    name: "OFF",
                    value: "OFF",
                  },
                ],
              },
            ],
          },
          {
            name: "antiinvites",
            description: "Autoriser ou interdire l'envoi d'invitations discord dans le message",
            type: "SUB_COMMAND",
            options: [
              {
                name: "status",
                description: "état de la configuration",
                required: true,
                type: "STRING",
                choices: [
                  {
                    name: "ON",
                    value: "ON",
                  },
                  {
                    name: "OFF",
                    value: "OFF",
                  },
                ],
              },
            ],
          },
          {
            name: "antilinks",
            description: "Autoriser ou interdire l'envoi de liens dans le message",
            type: "SUB_COMMAND",
            options: [
              {
                name: "status",
                description: "état de la configuration",
                required: true,
                type: "STRING",
                choices: [
                  {
                    name: "ON",
                    value: "ON",
                  },
                  {
                    name: "OFF",
                    value: "OFF",
                  },
                ],
              },
            ],
          },
          {
            name: "antiscam",
            description: "Activer ou désactiver la détection anti-scam",
            type: "SUB_COMMAND",
            options: [
              {
                name: "status",
                description: "état de la configuration",
                required: true,
                type: "STRING",
                choices: [
                  {
                    name: "ON",
                    value: "ON",
                  },
                  {
                    name: "OFF",
                    value: "OFF",
                  },
                ],
              },
            ],
          },
          {
            name: "maxlines",
            description: "Définit le nombre maximal de lignes autorisées par message",
            type: "SUB_COMMAND",
            options: [
              {
                name: "amount",
                description: "niveau de configuration (0 pour désactiver)",
                required: true,
                type: "INTEGER",
              },
            ],
          },
          {
            name: "maxmentions",
            description: "Définit le nombre maximal de mentions d'utilisateurs autorisées par message",
            type: "SUB_COMMAND",
            options: [
              {
                name: "amount",
                description: "niveau de configuration (0 pour désactiver)",
                required: true,
                type: "INTEGER",
              },
            ],
          },
          {
            name: "maxrolementions",
            description: "Définit le nombre maximal de mentions de rôle autorisées par message",
            type: "SUB_COMMAND",
            options: [
              {
                name: "amount",
                description: "niveau de configuration (0 pour désactiver)",
                required: true,
                type: "INTEGER",
              },
            ],
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   * @param {object} data
   */
  async messageRun(message, args, data) {
    const settings = data.settings;
    const sub = args[0].toLowerCase();

    let response;
    if (sub == "antighostping") {
      const status = args[1].toLowerCase();
      if (!["on", "off"].includes(status)) return message.reply("Statut invalide. La valeur doit être `on/off`");
      response = await antighostPing(settings, status);
    }

    //
    else if (sub === "antiinvites") {
      const status = args[1].toLowerCase();
      if (!["on", "off"].includes(status)) return message.reply("Statut invalide. La valeur doit être `on/off`");
      response = await antiInvites(settings, status);
    }

    //
    else if (sub == "antilinks") {
      const status = args[1].toLowerCase();
      if (!["on", "off"].includes(status)) return message.reply("Statut invalide. La valeur doit être `on/off`");
      response = await antilinks(settings, status);
    }

    //
    else if (sub == "antiscam") {
      const status = args[1].toLowerCase();
      if (!["on", "off"].includes(status)) return message.reply("Statut invalide. La valeur doit être `on/off`");
      response = await antiScam(settings, status);
    }

    //
    else if (sub === "maxlines") {
      const max = args[1];
      if (isNaN(max) || Number.parseInt(max) < 1) {
        return message.reply("Le nombre maximal de lignes doit être un nombre valide supérieur à 0");
      }
      response = await maxLines(settings, max);
    }

    //
    else if (sub === "maxmentions") {
      const max = args[1];
      if (isNaN(max) || Number.parseInt(max) < 1) {
        return message.reply("Le nombre maximal de mentions doit être un nombre valide supérieur à 0");
      }
      response = await maxMentions(settings, max);
    }

    //
    else if (sub === "maxrolementions") {
      const max = args[1];
      if (isNaN(max) || Number.parseInt(max) < 1) {
        return message.reply("Le nombre maximal de mentions role doit être un nombre valide supérieur à 0");
      }
      response = await maxRoleMentions(settings, max);
    }

    //
    else response = "Utilisation de la commande invalide !";

    await message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   * @param {object} data
   */
  async interactionRun(interaction, data) {
    const sub = interaction.options.getSubcommand();
    const settings = data.settings;

    let response;
    if (sub == "antighostping") response = await antighostPing(settings, interaction.options.getString("status"));
    else if (sub === "antiinvites") response = await antiInvites(settings, interaction.options.getString("status"));
    else if (sub == "antilinks") response = await antilinks(settings, interaction.options.getString("status"));
    else if (sub == "antiscam") response = await antiScam(settings, interaction.options.getString("status"));
    else if (sub === "maxlines") response = await maxLines(settings, interaction.options.getInteger("amount"));
    else if (sub === "maxmentions") response = await maxMentions(settings, interaction.options.getInteger("amount"));
    else if (sub === "maxrolementions") {
      response = await maxRoleMentions(settings, interaction.options.getInteger("amount"));
    }

    await interaction.followUp(response);
  }
};

async function antighostPing(settings, input) {
  const status = input.toUpperCase() === "ON" ? true : false;
  settings.automod.anti_ghostping = status;
  await settings.save();
  return `Configuration enregistrée ! Le ping antighost est maintenant ${status ? "enabled" : "disabled"}`;
}

async function antiInvites(settings, input) {
  const status = input.toUpperCase() === "ON" ? true : false;
  settings.automod.anti_invites = status;
  await settings.save();
  return `Messages ${
    status ? "avec discord les invitations seront désormais automatiquement supprimées" : "ne sera plus filtré pour les invitations discord maintenant"
  }`;
}

async function antilinks(settings, input) {
  const status = input.toUpperCase() === "ON" ? true : false;
  settings.automod.anti_links = status;
  await settings.save();
  return `Messages ${status ? "with links will now be automatically deleted" : "will not be filtered for links now"}`;
}

async function antiScam(settings, input) {
  const status = input.toUpperCase() === "ON" ? true : false;
  settings.automod.anti_scam = status;
  await settings.save();
  return `La détection anti-scam est maintenant ${status ? "enabled" : "disabled"}`;
}

async function maxLines(settings, input) {
  const lines = Number.parseInt(input);
  if (isNaN(lines)) return "Veuillez saisir un nombre valide";

  settings.automod.max_lines = lines;
  await settings.save();
  return `${
    input === 0
      ? "La limite de ligne maximale est désactivée"
      : `Messages plus longs que \`${input}\` lignes seront désormais automatiquement supprimées`
  }`;
}

async function maxMentions(settings, input) {
  const mentions = Number.parseInt(input);
  if (isNaN(mentions)) return "Veuillez saisir un nombre valide";

  settings.automod.max_mentions = mentions;
  await settings.save();
  return `${
    input === 0
      ? "La limite maximale de mentions d'utilisateurs est désactivée"
      : `Les messages ayant plus de \`${input}\` mentions d'utilisateurs seront désormais automatiquement supprimées`
  }`;
}

async function maxRoleMentions(settings, input) {
  const mentions = Number.parseInt(input);
  if (isNaN(mentions)) return "Veuillez saisir un nombre valide";

  settings.automod.max_role_mentions = mentions;
  await settings.save();
  return `${
    input === 0
      ? "La limite maximale de mentions de rôle est désactivée"
      : `Les messages ayant plus de \`${input}\` mentions de rôle seront désormais automatiquement supprimées`
  }`;
}