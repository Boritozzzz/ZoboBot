const { Command } = require("@src/structures");
const { Message, MessageEmbed, CommandInteraction } = require("discord.js");
const { EMBED_COLORS } = require("@root/config.js");
const { table } = require("table");

module.exports = class AutomodConfigCommand extends Command {
  constructor(client) {
    super(client, {
      name: "automodconfig",
      description: "diverses configurations d'automod",
      category: "AUTOMOD",
      userPermissions: ["MANAGE_GUILD"],
      command: {
        enabled: true,
        minArgsCount: 1,
        subcommands: [
          {
            trigger: "status",
            description: "vérifier la configuration automod pour cette guilde",
          },
          {
            trigger: "strikes <number>",
            description: "nombre maximum d'avertissements qu'un membre peut recevoir avant d'effectuer une action",
          },
          {
            trigger: "action <MUTE|KICK|BAN>",
            description: "définir l'action à effectuer après avoir reçu le maximum de warn",
          },
          {
            trigger: "debug <ON|OFF>",
            description: "active l'automod pour les messages envoyés par les administrateurs et les modérateurs",
          },
        ],
      },
      slashCommand: {
        enabled: true,
        ephemeral: true,
        options: [
          {
            name: "status",
            description: "Vérifier la configuration de l'automod",
            type: "SUB_COMMAND",
          },
          {
            name: "strikes",
            description: "Définir le nombre maximum d'avertissements avant d'effectuer une action",
            type: "SUB_COMMAND",
            options: [
              {
                name: "amount",
                description: "nombre de warn (par défaut 5)",
                required: true,
                type: "INTEGER",
              },
            ],
          },
          {
            name: "action",
            description: "Définir l'action à effectuer après avoir reçu le maximum de warn",
            type: "SUB_COMMAND",
            options: [
              {
                name: "action",
                description: "action à effectuer",
                type: "STRING",
                required: true,
                choices: [
                  {
                    name: "MUTE",
                    value: "MUTE",
                  },
                  {
                    name: "KICK",
                    value: "KICK",
                  },
                  {
                    name: "BAN",
                    value: "BAN",
                  },
                ],
              },
            ],
          },
          {
            name: "debug",
            description: "Activer/désactiver l'automod pour les messages envoyés par les administrateurs et les modérateurs",
            type: "SUB_COMMAND",
            options: [
              {
                name: "status",
                description: "état de la configuration",
                required: true,
                type: "STRING",
                choices: [
                  {
                    name: "ON",
                    value: "ON",
                  },
                  {
                    name: "OFF",
                    value: "OFF",
                  },
                ],
              },
            ],
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   * @param {object} data
   */
  async messageRun(message, args, data) {
    const input = args[0].toLowerCase();
    const settings = data.settings;

    let response;
    if (input === "status") {
      response = await getStatus(settings, message.guild);
    }

    if (input === "strikes") {
      const strikes = args[1];
      if (isNaN(strikes) || Number.parseInt(strikes) < 1) {
        return message.reply("Les avertissements doivent être un nombre valide supérieur à 0");
      }
      response = await setStrikes(settings, strikes);
    }

    if (input === "action") {
      const action = args[1].toUpperCase();
      if (!action || !["MUTE", "KICK", "BAN"].includes(action))
        return message.reply("Pas une action valide. L'action peut être `Mute`/`Kick`/`Ban`");
      response = await setAction(settings, message.guild, action);
    }

    if (input === "debug") {
      const status = args[1].toLowerCase();
      if (!["on", "off"].includes(status)) return message.reply("Statut invalide. La valeur doit être `on/off`");
      response = await setDebug(settings, status);
    }
//
    else response = "Utilisation de la commande non valide!";
    await message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   * @param {object} data
   */
  async interactionRun(interaction, data) {
    const sub = interaction.options.getSubcommand();
    const settings = data.settings;

    let response;

    // status
    if (sub === "status") response = await getStatus(settings, interaction.guild);
    else if (sub === "strikes") response = await setStrikes(settings, interaction.options.getInteger("amount"));
    else if (sub === "action")
      response = await setAction(settings, interaction.guild, interaction.options.getString("action"));
    else if (sub === "debug") response = await setDebug(settings, interaction.options.getString("status"));

    await interaction.followUp(response);
  }
};

async function getStatus(settings, guild) {
  const { automod } = settings;
  const row = [];

  const logChannel = settings.modlog_channel
    ? guild.channels.cache.get(settings.modlog_channel).toString()
    : "Not Configured";

  row.push(["Max Lines", automod.max_lines || "<:emoji_17:885086787700154388>"]);
  row.push(["Max Mentions", automod.max_mentions || "<:emoji_17:885086787700154388>"]);
  row.push(["Max Role Mentions", automod.max_role_mentions || "<:emoji_17:885086787700154388>"]);
  row.push(["Anti-Links", automod.anti_links ? "<:valide:885075251371835402>" : "<:emoji_17:885086787700154388>"]);
  row.push(["Anti-Invites", automod.anti_invites ? "<:valide:885075251371835402>" : "<:emoji_17:885086787700154388>"]);
  row.push(["Anti-Scam", automod.anti_scam ? "<:valide:885075251371835402>" : "<:emoji_17:885086787700154388>"]);
  row.push(["Anti-Ghostping", automod.anti_ghostping ? "<:valide:885075251371835402>" : "<:emoji_17:885086787700154388>"]);

  const asciiTable = table(row, {
    singleLine: true,
   
    
  });

  const embed = new MessageEmbed()
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setTitle("__**Configuration automatique**__")
    .setDescription("" + asciiTable + "")
    .addField("__**salon de log**__", logChannel, true)
    .addField("__**warn maximales**__", automod.strikes.toString(), true)
    .addField("__**Action**__", automod.action, true);

  return { embeds: [embed] };
}

async function setStrikes(settings, strikes) {
  settings.automod.strikes = strikes;
  await settings.save();
  return `Configuration enregistrée ! Le nombre maximal d'avertissements est défini sur ${strikes}`;
}

async function setAction(settings, guild, action) {
  if (action === "MUTE") {
    if (!guild.me.permissions.has("MODERATE_MEMBERS")) {
      return "Je n'ai pas la permission de timeout des membres";
    }
  }

  if (action === "KICK") {
    if (!guild.me.permissions.has("KICK_MEMBERS")) {
      return "Je n'ai pas la permission d'expulser des membres";
    }
  }

  if (action === "BAN") {
    if (!guild.me.permissions.has("BAN_MEMBERS")) {
      return "Je n'ai pas la permission de ban des membres";
    }
  }

  settings.automod.action = action;
  await settings.save();
  return `Configuration enregistrée ! L'action Automod est définie sur ${action}`;
}

async function setDebug(settings, input) {
  const status = input.toLowerCase() === "on" ? true : false;
  settings.automod.debug = status;
  await settings.save();
  return `Configuration enregistrée ! Le débogage d'Automod est maintenant ${status ? "enabled" : "disabled"}`;
}