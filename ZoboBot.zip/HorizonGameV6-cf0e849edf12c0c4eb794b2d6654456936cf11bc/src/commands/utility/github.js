const { Command } = require("@src/structures");
const { MessageEmbed, Message, CommandInteraction } = require("discord.js");
const { MESSAGES } = require("@root/config.js");
const { getJson } = require("@utils/httpUtils");
const { stripIndent } = require("common-tags");

module.exports = class GithubCommand extends Command {
  constructor(client) {
    super(client, {
      name: "github",
      description: "affiche les statistiques github d'un utilisateur",
      cooldown: 10,
      category: "UTILITY",
      botPermissions: ["EMBED_LINKS"],
      command: {
        enabled: true,
        aliases: ["git"],
        usage: "<nom d'utilisateur>",
        minArgsCount: 1,
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "username",
            description: "nom d'utilisateur github",
            type: "STRING",
            required: true,
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   */
  async messageRun(message, args) {
    const username = args.join(" ");
    const response = await getGithubUser(username, message.author);
    await message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   */
  async interactionRun(interaction) {
    const username = interaction.options.getString("username");
    const response = await getGithubUser(username, interaction.user);
    await interaction.followUp(response);
  }
};

const websiteProvided = (text) => (text.startsWith("http://") ? true : text.startsWith("https://"));

async function getGithubUser(target, author) {
  const response = await getJson(`https://api.github.com/users/${target}`);
  if (response.status === 404) return "```Aucun utilisateur trouvé avec ce nom```";
  if (!response.success) return MESSAGES.API_ERROR;

  const json = response.data;
  const {
    login: username,
    name,
    id: githubId,
    avatar_url: avatarUrl,
    html_url: userPageLink,
    followers,
    following,
    bio,
    location,
    blog,
  } = json;

  let website = websiteProvided(blog) ? `[Cliquez sur moi](${blog})` : "Non fourni";
  if (website == null) website = "Non fourni";

  const embed = new MessageEmbed()
    .setAuthor({
      name: `Utilisateur GitHub: ${username}`,
      url: userPageLink,
      iconURL: avatarUrl,
    })
    .addField(
      "informations utilisateur",
      stripIndent`**Vrai nom**: *${name || "Non fourni"}*
        **Lieu**: *${location}*
        **ID GitHub**: *${githubId}*
        **Site Internet**: *${website}*\n`,
      true
    )
    .addField("Statistiques sociales", `**Suiveurs**: *${followers}*\n**Suivant**: *${following}*`, true)
    .setDescription(`**Bio**:\n${bio || "Non fourni"}`)
    .setImage(avatarUrl)
    .setColor(0x6e5494)
    .setFooter({ text: `Demandé par ${author.tag}` });

  return { embeds: [embed] };
}