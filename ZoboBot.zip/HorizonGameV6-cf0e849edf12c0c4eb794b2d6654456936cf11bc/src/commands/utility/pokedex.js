const { Command } = require("@src/structures");
const { MessageEmbed, Message, CommandInteraction } = require("discord.js");
const { MESSAGES, EMBED_COLORS } = require("@root/config.js");
const { getJson } = require("@utils/httpUtils");
const { stripIndent } = require("common-tags");

module.exports = class Pokedex extends Command {
  constructor(client) {
    super(client, {
      name: "pokedex",
      description: "affiche des informations sur les pokémons",
      category: "UTILITY",
      botPermissions: ["EMBED_LINKS"],
      cooldown: 5,
      command: {
        enabled: true,
        usage: "<pokémon>",
        minArgsCount: 1,
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "pokemon",
            description: "nom de pokemon pour obtenir des informations",
            type: "STRING",
            required: true,
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   */
  async messageRun(message, args) {
    const pokemon = args.join(" ");
    const response = await pokedex(pokemon);
    await message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   */
  async interactionRun(interaction) {
    const pokemon = interaction.options.getString("pokemon");
    const response = await pokedex(pokemon);
    await interaction.followUp(response);
  }
};

async function pokedex(pokemon) {
  const response = await getJson(`https://pokeapi.glitch.me/v1/pokemon/${pokemon}`);
  if (response.status === 404) return "```Le pokémon donné est introuvable```";
  if (!response.success) return MESSAGES.API_ERROR;

  const json = response.data[0];

  const embed = new MessageEmbed()
    .setTitle(`Pokédex - ${json.name}`)
    .setColor("RANDOM")
    .setThumbnail(json.sprite)
    .setDescription(
      stripIndent`
            ♢ **ID**: ${json.number}
            ♢ **Nom**: ${json.name}
            ♢ **Espèce**: ${json.species}
            ♢ **Type(s)**: ${json.types}
            ♢ **Capacités(normal)**: ${json.abilities.normal}
            ♢ **Capacités (cachées)**: ${json.abilities.hidden}
            ♢ **Groupe d'œuf(s)**: ${json.eggGroups}
            ♢ **Genre**: ${json.gender}
            ♢ **Hauteur**: ${json.height} foot tall
            ♢ **Poids**: ${json.weight}
            ♢ **Étape d'évolution actuelle**: ${json.family.evolutionStage}
            ♢ **Ligne Évolution**: ${json.family.evolutionLine}
            ♢ **Est-ce un Starter ?**: ${json.starter}
            ♢ **Légendaire?**: ${json.legendary}
            ♢ **Mythique ?**: ${json.mythical}
            ♢ **Génération?**: ${json.gen}
            `
    )
    .setFooter({ text: json.description });

  return { embeds: [embed] };
}