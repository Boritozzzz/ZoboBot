const { Command } = require("@src/structures");
const { MessageEmbed, Message, CommandInteraction } = require("discord.js");
const { postToBin } = require("@utils/httpUtils");

module.exports = class PasteCommand extends Command {
  constructor(client) {
    super(client, {
      name: "paste",
      description: "Collez quelque chose dans sourceb.in",
      cooldown: 5,
      category: "UTILITY",
      botPermissions: ["EMBED_LINKS"],
      command: {
        enabled: true,
        minArgsCount: 2,
        usage: "<titre> <contenu>",
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "title",
            description: "titre de votre contenu",
            required: true,
            type: "STRING",
          },
          {
            name: "content",
            description: "contenu à publier",
            type: "STRING",
            required: true,
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   */
  async messageRun(message, args) {
    const title = args.shift();
    const content = args.join(" ");
    const response = await paste(content, title);
    await message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   */
  async interactionRun(interaction) {
    const title = interaction.options.getString("title");
    const content = interaction.options.getString("content");
    const response = await paste(content, title);
    await interaction.followUp(response);
  }
};

async function paste(content, title) {
  const response = await postToBin(content, title);
  if (!response) return "<:emoji_17:885086787700154388> Quelque chose s'est mal passé";

  const embed = new MessageEmbed()
    .setTitle("__LIENS DU PASTE__")
    .setColor("RANDOM")
    .setDescription(`\n🔸 Normal: ${response.url}\n🔹 Raw: ${response.raw}`);

  return { embeds: [embed] };
}
