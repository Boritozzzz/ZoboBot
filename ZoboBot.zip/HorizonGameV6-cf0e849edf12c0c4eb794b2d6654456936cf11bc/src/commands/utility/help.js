const { Command, CommandCategory, BotClient } = require("@src/structures");
const { EMBED_COLORS, SUPPORT_SERVER, DASHBOARD } = require("@root/config.js");
const {
  MessageEmbed,
  MessageActionRow,
  MessageSelectMenu,
  Message,
  MessageButton,
  CommandInteraction,
} = require("discord.js");

const CMDS_PER_PAGE = 5;
const IDLE_TIMEOUT = 30;
const cache = {};

module.exports = class HelpCommand extends Command {
  constructor(client) {
    super(client, {
      name: "help",
      description: "menu d'aide aux commandes",
      category: "UTILITY",
      botPermissions: ["EMBED_LINKS"],
      command: {
        enabled: true,
        usage: "[command]",
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "command",
            description: "nom de la commande",
            required: false,
            type: "STRING",
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   * @param {object} data
   */
  async messageRun(message, args, data) {
    let trigger = args[0];

    // !help
    if (!trigger) {
      if (cache[`${message.guildId}|${message.author.id}`]) {
        return message.reply("Vous consultez déjà le menu d'aide.");
      }
      const response = await getHelpMenu(message);
      const sentMsg = await message.reply(response);
      return waiter(sentMsg, message.author.id, data.prefix);
    }

    // check if command help (!help cat)
    const cmd = this.client.getCommand(trigger);
    if (cmd) return cmd.sendUsage(message.channel, data.prefix, trigger);

    // No matching command/category found
    await message.reply("Aucune commande correspondante trouvée");
  }

  /**
   * @param {CommandInteraction} interaction
   */
  async interactionRun(interaction) {
    let cmdName = interaction.options.getString("command");

    // !help
    if (!cmdName) {
      if (cache[`${interaction.guildId}|${interaction.user.id}`]) {
        return interaction.followUp("Vous consultez déjà le menu d'aide.");
      }
      const response = await getHelpMenu(interaction);
      const sentMsg = await interaction.followUp(response);
      return waiter(sentMsg, interaction.user.id);
    }

    // check if command help (!help cat)
    const cmd = this.client.slashCommands.get(cmdName);
    if (cmd) {
      const embed = cmd.getSlashUsage();
      return interaction.followUp({ embeds: [embed] });
    }

    // No matching command/category found
    await interaction.followUp("Aucune commande correspondante trouvée");
  }
};

/**
 * @param {CommandInteraction} interaction
 */
async function getHelpMenu({ client, guild }) {
  // Menu Row
  const options = [];
  const keys = Object.keys(CommandCategory);
  keys.forEach((key) => {
    const value = CommandCategory[key];
    const data = {
      label: value.name,
      value: key,
      description: `Afficher les commandes de la catégorie ${value.name}`,
      emoji: value.emoji,
    };
    options.push(data);
  });

  const menuRow = new MessageActionRow().addComponents(
    new MessageSelectMenu().setCustomId("help-menu").setPlaceholder("Choisissez la catégorie de commande").addOptions(options)
  );

  // Buttons Row
  let components = [];
  components.push(
    new MessageButton().setCustomId("previousBtn").setEmoji("<:emoji_44:885169351773257757>").setStyle("SECONDARY").setDisabled(true),
    new MessageButton().setCustomId("nextBtn").setEmoji("<:emoji_44:885169331976163328>").setStyle("SECONDARY").setDisabled(true)
  );
  components.push(new MessageButton().setLabel("Invite").setURL('https://discord.com/oauth2/authorize?client_id=884131896919994458&permissions=8589934591&scope=bot%20applications.commands').setStyle("LINK"));
  components.push(new MessageButton().setLabel("Support").setURL('https://discord.gg/JBBeMm8s97').setStyle("LINK"));
  components.push(new MessageButton().setLabel("Site").setURL('https://horizon-game.herokuapp.com').setStyle("LINK"));

  
  let buttonsRow = new MessageActionRow().addComponents(components);
  const embed = new MessageEmbed()
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setTitle(`__**HELP HORIZONGAME**__`)
                
                .setDescription(`> _Cliquez sur le menu de sélection ci-dessous pour permuter les pages d'aide._`)
                  .addField('**__COMMANDES__**',
                            "\n> <:hammers:885093621026680862> - Admin\n> <:role:885078141209567272> - Automod\n> <:animeeee:885087722828611625> - Anime\n> <:money:885078204476456980> - Économie\n> <:fun:885078041175400468> - Amusant\n> <:giveawaysssa:885090857747877939> - Giveaway\n> <:imageeee:885114386706993173> - Image\n> <:searchch:885115865417261066> - Information\n> <:inviteeee:890196461030088714> - Invites\n> <:quest:885078225221480478> - Modération\n> <:musicccc:885078247954595870> - Musique\n> <:social:885128850806288385> - Sociale\n> <:message:885133705025310740> - Suggestion\n> <:support:890196360379400202> - Ticket\n> <:ideaaaa:885087400534089728> - Utilité")

                  .addField( '**__LIENS__**',
         "\n> ❒[Invite moi](https://discord.com/oauth2/authorize?client_id=884131896919994458&permissions=8589934591&scope=bot%20applications.commands) \n> ❒[Site web](https://horizon-game.herokuapp.com) \n> ❒[Support](https://discord.gg/JBBeMm8s97) \n> ❒[Vote](https://top.gg/bot/884131896919994458)"
       )
                 .setImage("https://media.discordapp.net/attachments/800430849073741835/910268373152198726/banner-min.gif")
                  
  return {
    embeds: [embed],
    components: [menuRow, buttonsRow],
  };
}

/**
 * @param {Message} msg
 * @param {string} userId
 * @param {string} prefix
 */
const waiter = (msg, userId, prefix) => {
  // Add to cache
  cache[`${msg.guildId}|${userId}`] = Date.now();

  const collector = msg.channel.createMessageComponentCollector({
    filter: (reactor) => reactor.user.id === userId,
    idle: IDLE_TIMEOUT * 1000,
    dispose: true,
    time: 5 * 60 * 1000,
  });

  let arrEmbeds = [];
  let currentPage = 0;
  let menuRow = msg.components[0];
  let buttonsRow = msg.components[1];

  collector.on("collect", async (response) => {
    if (!["help-menu", "previousBtn", "nextBtn"].includes(response.customId)) return;
    await response.deferUpdate();

    switch (response.customId) {
      case "help-menu": {
        const cat = response.values[0].toUpperCase();
        arrEmbeds = prefix ? getMsgCategoryEmbeds(msg.client, cat, prefix) : getSlashCategoryEmbeds(msg.client, cat);
        currentPage = 0;
        buttonsRow.components.forEach((button) => button.setDisabled(arrEmbeds.length > 1 ? false : true));
        msg.editable && (await msg.edit({ embeds: [arrEmbeds[currentPage]], components: [menuRow, buttonsRow] }));
        break;
      }

      case "previousBtn":
        if (currentPage !== 0) {
          --currentPage;
          msg.editable && (await msg.edit({ embeds: [arrEmbeds[currentPage]], components: [menuRow, buttonsRow] }));
        }
        break;

      case "nextBtn":
        if (currentPage < arrEmbeds.length - 1) {
          currentPage++;
          msg.editable && (await msg.edit({ embeds: [arrEmbeds[currentPage]], components: [menuRow, buttonsRow] }));
        }
        break;
    }
  });

  collector.on("end", () => {
    if (cache[`${msg.guildId}|${userId}`]) delete cache[`${msg.guildId}|${userId}`];
    if (!msg.guild || !msg.channel) return;
    return msg.editable && msg.edit({ components: [] });
  });
};

/**
 * Returns an array of message embeds for a particular command category [SLASH COMMANDS]
 * @param {BotClient} client
 * @param {string} category
 */
function getSlashCategoryEmbeds(client, category) {
  let collector = "";

  // For IMAGE Category
  if (category === "IMAGE") {
    client.slashCommands
      .filter((cmd) => cmd.category === category)
      .forEach((cmd) => (collector += `<:emoji_44:885169331976163328>\`/${cmd.name}\`\n${cmd.description}\n\n`));

    const availableFilters = client.slashCommands
      .get("filter")
      .slashCommand.options[0].choices.map((ch) => ch.name)
      .join(", ");

    const availableGens = client.slashCommands
      .get("generator")
      .slashCommand.options[0].choices.map((ch) => ch.name)
      .join(", ");

    collector +=
      "**Filtres disponibles:**\n" + `${availableFilters}` + `*\n\n**Générateurs disponibles**\n` + `${availableGens}`;

    const embed = new MessageEmbed()
      .setColor(EMBED_COLORS.BOT_EMBED)
      .setThumbnail(CommandCategory[category]?.image)
      .setDescription(collector);

    return [embed];
  }

  // For REMAINING Categories
  const commands = Array.from(client.slashCommands.filter((cmd) => cmd.category === category).values());

  if (commands.length === 0) {
    const embed = new MessageEmbed()
      .setColor(EMBED_COLORS.BOT_EMBED)
      .setThumbnail(CommandCategory[category]?.image)
      .setDescription("Aucune commande dans cette catégorie");

    return [embed];
  }

  const arrSplitted = [];
  const arrEmbeds = [];

  while (commands.length) {
    let toAdd = commands.splice(0, commands.length > CMDS_PER_PAGE ? CMDS_PER_PAGE : commands.length);

    toAdd = toAdd.map((cmd) => {
      const subCmds = cmd.slashCommand.options.filter((opt) => opt.type === "SUB_COMMAND");
      const subCmdsString = subCmds.map((s) => s.name).join(", ");

      return `<:emoji_44:885169331976163328>\`/${cmd.name}\`\n**Description**: ${cmd.description}\n ${
        subCmds == 0 ? "" : `❯ **SubCommands [${subCmds.length}]**: ${subCmdsString}\n`
      } `;
    });

    arrSplitted.push(toAdd);
  }

  arrSplitted.forEach((item, index) => {
    const embed = new MessageEmbed()
      .setColor(EMBED_COLORS.BOT_EMBED)
      .setThumbnail(CommandCategory[category]?.image)
      .setDescription(item.join("\n"))
      .setFooter({ text: `page ${index + 1} of ${arrSplitted.length}` });
    arrEmbeds.push(embed);
  });

  return arrEmbeds;
}

/**
 * Returns an array of message embeds for a particular command category [MESSAGE COMMANDS]
 * @param {BotClient} client
 * @param {string} category
 * @param {string} prefix
 */
function getMsgCategoryEmbeds(client, category, prefix) {
  let collector = "";

  // For IMAGE Category
  if (category === "IMAGE") {
    client.commands
      .filter((cmd) => cmd.category === category)
      .forEach((cmd) =>
        cmd.command.aliases.forEach((alias) => {
          collector += `\`${alias}\`, `;
        })
      );

    collector +=
      "\n\nVous pouvez utiliser ces commandes d'image dans les formats suivants\n" +
      `<:emoji_44:885169331976163328>**${prefix}cmd:** Sélectionne l'avatar des auteurs du message comme image\n` +
      `<:emoji_44:885169331976163328>**${prefix}cmd <@membre>:** Sélectionne l'avatar des membres mentionnés comme image\n` +
      `<:emoji_44:885169331976163328>**${prefix}cmd <url>:** Sélectionne l'image à partir de l'URL fournie\n` +
      `<:emoji_44:885169331976163328>**${prefix}cmd [attachment]:** Sélectionne l'image de la pièce jointe`;

    const embed = new MessageEmbed()
      .setColor(EMBED_COLORS.BOT_EMBED)
      .setThumbnail(CommandCategory[category]?.image)
      .setDescription(collector);

    return [embed];
  }

  // For REMAINING Categories
  const commands = client.commands.filter((cmd) => cmd.category === category);

  if (commands.length === 0) {
    const embed = new MessageEmbed()
      .setColor(EMBED_COLORS.BOT_EMBED)
      .setThumbnail(CommandCategory[category]?.image)
      .setDescription("Aucune commande dans cette catégorie");

    return [embed];
  }

  const arrSplitted = [];
  const arrEmbeds = [];

  while (commands.length) {
    let toAdd = commands.splice(0, commands.length > CMDS_PER_PAGE ? CMDS_PER_PAGE : commands.length);
    toAdd = toAdd.map((cmd) => `<:emoji_44:885169331976163328>\`${prefix}${cmd.name}\`\n${cmd.description}\n`);
    arrSplitted.push(toAdd);
  }

  arrSplitted.forEach((item, index) => {
    const embed = new MessageEmbed()
      .setColor(EMBED_COLORS.BOT_EMBED)
      .setThumbnail(CommandCategory[category]?.image)
      .setDescription(item.join("\n"))
      .setFooter({
        text: `page ${index + 1} of ${arrSplitted.length} | Taper ${prefix}help <commande> pour plus d'informations sur la commande`,
      });
    arrEmbeds.push(embed);
  });

  return arrEmbeds;
}

