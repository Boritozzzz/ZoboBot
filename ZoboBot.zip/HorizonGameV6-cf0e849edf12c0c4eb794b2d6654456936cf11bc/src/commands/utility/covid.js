const { MessageEmbed, Message, CommandInteraction } = require("discord.js");
const { Command } = require("@src/structures");
const { MESSAGES, EMBED_COLORS } = require("@root/config.js");
const { getJson } = require("@utils/httpUtils");
const timestampToDate = require("timestamp-to-date");

module.exports = class CovidCommand extends Command {
  constructor(client) {
    super(client, {
      name: "covid",
      description: "obtenir des statistiques covid pour un pays",
      cooldown: 5,
      category: "UTILITY",
      botPermissions: ["EMBED_LINKS"],
      command: {
        enabled: true,
        usage: "<Pays>",
        minArgsCount: 1,
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "country",
            description: "nom du pays pour lequel obtenir des statistiques covid",
            type: "STRING",
            required: true,
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   */
  async messageRun(message, args) {
    const country = args.join(" ");
    const response = await getCovid(country);
    await message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   */
  async interactionRun(interaction) {
    const country = interaction.options.getString("country");
    const response = await getCovid(country);
    await interaction.followUp(response);
  }
};

async function getCovid(country) {
  const response = await getJson(`https://disease.sh/v2/countries/${country}`);

  if (response.status === 404) return "```css\nLe pays avec le nom fourni est introuvable```";
  if (!response.success) return MESSAGES.API_ERROR;
  const { data } = response;

  const mg = timestampToDate(data?.updated, "dd.MM.yyyy at HH:mm");
  const embed = new MessageEmbed()
    .setTitle(`__COVID - ${data?.country}__`)
    .setThumbnail(data?.countryInfo.flag)
    .setColor(EMBED_COLORS.BOT_EMBED)
    .addField("<:emoji_44:885169331976163328>__Total des cas__", data?.cases.toString(), true)
    .addField("<:emoji_44:885169331976163328>__Cas aujourd'hui__", data?.todayCases.toString(), true)
    .addField("<:emoji_44:885169331976163328>__Décès totaux__", data?.deaths.toString(), true)
    .addField("<:emoji_44:885169331976163328>__Décès aujourd'hui__", data?.todayDeaths.toString(), true)
    .addField("<:emoji_44:885169331976163328>__Rétabli__", data?.recovered.toString(), true)
    .addField("<:emoji_44:885169331976163328>__Actif__", data?.active.toString(), true)
    .addField("<:emoji_44:885169331976163328>__Critique__", data?.critical.toString(), true)
    .addField("<:emoji_44:885169331976163328>__Cas pour 1 million__", data?.casesPerOneMillion.toString(), true)
    .addField("<:emoji_44:885169331976163328>__Décès pour 1 million__", data?.deathsPerOneMillion.toString(), true)
    .setFooter({ text: `Dernière mise à jour le ${mg}` });

  return { embeds: [embed] };
}
