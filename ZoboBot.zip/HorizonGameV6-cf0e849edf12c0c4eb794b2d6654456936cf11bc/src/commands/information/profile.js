const { Command } = require("@src/structures");
const { Message, CommandInteraction, MessageEmbed } = require("discord.js");
const { getUser } = require("@schemas/User");
const { getMember } = require("@schemas/Member");
const { EMBED_COLORS, ECONOMY } = require("@root/config");

module.exports = class Profile extends Command {
  constructor(client) {
    super(client, {
      name: "profile",
      description: "affiche le profil des membres",
      cooldown: 5,
      category: "INFORMATION",
      command: {
        enabled: true,
        usage: "[@member|id]",
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "user",
            description: "utilisateur cible",
            type: "USER",
            required: false,
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   * @param {object} data
   */
  async messageRun(message, args, data) {
    const target = (await message.guild.resolveMember(args[0])) || message.member;
    const response = await profile(message, target.user, data.settings);
    await message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   * @param {object} data
   */
  async interactionRun(interaction, data) {
    const user = interaction.options.getUser("user") || interaction.user;
    const response = await profile(interaction, user, data.settings);
    await interaction.followUp(response);
  }
};

async function profile({ guild }, user, settings) {
  const memberData = await getMember(guild.id, user.id);
  const userData = await getUser(user.id);

  const embed = new MessageEmbed()
    .setThumbnail(user.displayAvatarURL())
    .setColor(EMBED_COLORS.BOT_EMBED)
    .addField("**__Tag__**", user.tag, true)
    .addField("__**ID**__", user.id, true)
    .addField("**__Discord Registered__**", user.createdAt.toDateString(), false)
    .addField("**__Cash__**", `${userData.coins} ${ECONOMY.CURRENCY}`, true)
    .addField("**__Bank__**", `${userData.bank} ${ECONOMY.CURRENCY}`, true)
    .addField("**__Net Worth__**", `${userData.coins + userData.bank}${ECONOMY.CURRENCY}`, true)
    .addField("__**Reputation**__", `${userData.reputation.received}`, true)
    .addField("__**Daily Streak**__", `${userData.daily.streak}`, true)
    .addField("**__XP__**", `${settings.ranking.enabled ? memberData.xp + " " : "Not Tracked"}`, true)
    .addField("__**Level**__", `${settings.ranking.enabled ? memberData.level + " " : "Not Tracked"}`, true)
    .addField("__**Strikes**__", memberData.strikes + " ", true)
    .addField("__**Warnings**__", memberData.warnings + " ", true)
    .setFooter({ text: "Fields marked (*) are guild specific" });

  return { embeds: [embed] };
}