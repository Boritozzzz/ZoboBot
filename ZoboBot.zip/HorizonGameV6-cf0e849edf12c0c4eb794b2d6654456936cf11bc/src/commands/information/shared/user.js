const { MessageEmbed } = require("discord.js");
const { EMBED_COLORS } = require("@root/config");

module.exports = (member) => {
  let color = EMBED_COLORS.BOT_EMBED

  const embed = new MessageEmbed()
    .setAuthor({
      name: `${member.displayName}`,
      iconURL: member.user.displayAvatarURL(),
    })
    .setThumbnail(member.user.displayAvatarURL())
    .setColor(color)
    .addField("<:emoji_44:885169331976163328>__Tag__", member.user.tag, true)
    .addField("<:emoji_44:885169331976163328>__ID__", member.id, true)
    .addField("<:emoji_44:885169331976163328>__Rejoint__", member.joinedAt.toUTCString())
    .addField("<:emoji_44:885169331976163328>__Discord__", member.user.createdAt.toUTCString())
    .setFooter({ text: `Demandé par ${member.user.tag}` })
    .setTimestamp(Date.now());

  return { embeds: [embed] };
};
