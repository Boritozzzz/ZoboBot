const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js");
const { EMBED_COLORS, SUPPORT_SERVER, DASHBOARD } = require("@root/config");

module.exports = (client) => {
  const embed = new MessageEmbed()
    .setTitle("**__INVITE__**")
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setThumbnail(client.user.displayAvatarURL())
    .setDescription("Salut! Merci d'avoir envisagé de m'inviter\nUtilisez le bouton ci-dessous pour naviguer où vous voulez");

  // Buttons
  let components = [];
  components.push(new MessageButton().setLabel("Dashboard").setURL('https://horizon-game.herokuapp.com').setStyle("LINK"));
  components.push(new MessageButton().setLabel("Support").setURL('https://discord.gg/JBBeMm8s97').setStyle("LINK"));
  components.push(new MessageButton().setLabel("Invite").setURL('https://discord.com/oauth2/authorize?client_id=884131896919994458&permissions=8589934591&scope=bot%20applications.commands').setStyle("LINK"));
  components.push(new MessageButton().setLabel("Site").setURL('https://horizongame.ml').setStyle("LINK"));
  components.push(new MessageButton().setLabel("Vote").setURL('https://top.gg/bot/884131896919994458').setStyle("LINK"));

  let buttonsRow = new MessageActionRow().addComponents(components);
  return { embeds: [embed], components: [buttonsRow] };
};
