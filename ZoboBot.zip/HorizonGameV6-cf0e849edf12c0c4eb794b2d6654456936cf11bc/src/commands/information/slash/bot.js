const { Command } = require("@src/structures");
const { MessageEmbed, MessageButton, MessageActionRow, CommandInteraction } = require("discord.js");
const { timeformat } = require("@utils/miscUtils");
const { EMBED_COLORS, SUPPORT_SERVER, DASHBOARD } = require("@root/config.js");
const botstats = require("../shared/botstats");

module.exports = class BotCommand extends Command {
  constructor(client) {
    super(client, {
      name: "bot",
      description: "commandes liées au bot",
      category: "INFORMATION",
      botPermissions: ["EMBED_LINKS"],
      command: {
        enabled: false,
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "invite",
            description: "obtenir l'invitation du bot",
            type: "SUB_COMMAND",
          },
          {
            name: "stats",
            description: "obtenir les statistiques du bot",
            type: "SUB_COMMAND",
          },
          {
            name: "uptime",
            description: "obtenir la disponibilité du bot",
            type: "SUB_COMMAND",
          },
        ],
      },
    });
  }

  /**
   * @param {CommandInteraction} interaction
   */
  async interactionRun(interaction) {
    const sub = interaction.options.getSubcommand();
    if (!sub) return interaction.followUp("Pas une sous-commande valide");

    // Invite
    if (sub === "invite") {
      const response = botInvite(interaction.client);
      try {
        await interaction.user.send(response);
        return interaction.followUp("Vérifiez votre DM pour mes informations! :envelope_with_arrow:");
      } catch (ex) {
        return interaction.followUp("Je ne peux pas vous envoyer mes informations ! Votre DM est-il ouvert ?");
      }
    }

    // Stats
    else if (sub === "stats") {
      const response = botstats(interaction.client);
      return interaction.followUp(response);
    }

    // Uptime
    else if (sub === "uptime") {
      await interaction.followUp(`Uptime: \`${timeformat(process.uptime())}\``);
    }
  }
};

function botInvite(client) {
  const embed = new MessageEmbed()
    .setAuthor({ name: "Invite" })
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setThumbnail(client.user.displayAvatarURL())
    .setDescription("Salut! Merci d'avoir envisagé de m'inviter\Utilisez le bouton ci-dessous pour naviguer où vous voulez");

  // Buttons
  let components = [];
    components.push(new MessageButton().setLabel("Invite").setURL(client.getInvite()).setStyle("LINK"));
  components.push(new MessageButton().setLabel("Support").setURL('https://discord.gg/JBBeMm8s97').setStyle("LINK"));
  components.push(new MessageButton().setLabel("Site").setURL('https://horizongame.ml').setStyle("LINK"));

  let buttonsRow = new MessageActionRow().addComponents(components);
  return { embeds: [embed], components: [buttonsRow] };
}
