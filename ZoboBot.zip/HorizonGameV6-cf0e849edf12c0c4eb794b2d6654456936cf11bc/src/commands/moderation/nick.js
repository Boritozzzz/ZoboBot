const { Command } = require("@src/structures");
const { Message, CommandInteraction } = require("discord.js");
const { memberInteract } = require("@utils/modUtils");

module.exports = class NickCommand extends Command {
  constructor(client) {
    super(client, {
      name: "nick",
      description: "nickname commands",
      category: "MODERATION",
      botPermissions: ["MANAGE_NICKNAMES"],
      userPermissions: ["MANAGE_NICKNAMES"],
      command: {
        enabled: true,
        minArgsCount: 2,
        subcommands: [
          {
            trigger: "set <@member> <name>",
            description: "définit le surnom du membre spécifié",
          },
          {
            trigger: "reset <@member>",
            description: "réinitialiser le pseudo d'un membre",
          },
        ],
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "set",
            description: "changer le pseudo d'un membre",
            type: "SUB_COMMAND",
            options: [
              {
                name: "user",
                description: "le membre dont vous voulez définir le pseudo",
                type: "USER",
                required: true,
              },
              {
                name: "name",
                description: "le surnom à mettre",
                type: "STRING",
                required: true,
              },
            ],
          },
          {
            name: "reset",
            description: "réinitialiser le pseudo d'un membre",
            type: "SUB_COMMAND",
            options: [
              {
                name: "user",
                description: "les membres dont vous souhaitez réinitialiser le pseudo",
                type: "USER",
                required: true,
              },
            ],
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   */
  async messageRun(message, args) {
    const sub = args[0].toLowerCase();

    if (sub === "set") {
      const target = await message.guild.resolveMember(args[1], true);
      if (!target) return message.reply("Impossible de trouver le membre correspondant");
      const name = args.slice(2).join(" ");
      if (!name) return message.reply("Veuillez spécifier un surnom");

      const response = await nickname(message, target, name);
      return message.reply(response);
    }

    //
    else if (sub === "reset") {
      const target = await message.guild.resolveMember(args[1], true);
      if (!target) return message.reply("Impossible de trouver le membre correspondant");

      const response = await nickname(message, target);
      return message.reply(response);
    }
  }

  /**
   * @param {CommandInteraction} interaction
   */
  async interactionRun(interaction) {
    const name = interaction.options.getString("name");
    const target = await interaction.guild.members.fetch(interaction.options.getUser("user"));

    const response = await nickname(interaction, target, name);
    await interaction.followUp(response);
  }
};

async function nickname({ member, guild }, target, name) {
  if (!memberInteract(member, target)) {
    return `Oups! Vous ne pouvez pas gérer le pseudo de ${target.user.tag}`;
  }
  if (!memberInteract(guild.me, target)) {
    return `Oups! Je ne peux pas gérer le pseudo de ${target.user.tag}`;
  }

  try {
    await target.setNickname(name);
    return `${name ? "changed" : "reset"} le surnom de ${target.user.tag}`;
  } catch (ex) {
    return `Impossible de ${name ? "change" : "reset"} le surnom de ${target.displayName}. Avez-vous fourni un nom valide ?`;
  }
}
