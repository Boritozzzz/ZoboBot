const { Message } = require("discord.js");
const { Command } = require("@src/structures");
const { purgeMessages } = require("@utils/modUtils");

module.exports = class PurgeLinks extends Command {
  constructor(client) {
    super(client, {
      name: "purgelinks",
      description: "supprime le nombre spécifié de messages avec des liens",
      category: "MODERATION",
      userPermissions: ["MANAGE_MESSAGES"],
      botPermissions: ["MANAGE_MESSAGES", "READ_MESSAGE_HISTORY"],
      command: {
        enabled: true,
        usage: "[nombre]",
        aliases: ["purgelink"],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   */
  async messageRun(message, args) {
    const amount = args[0] || 99;

    if (amount) {
      if (isNaN(amount)) return message.reply("Seuls les chiffres sont autorisés");
      if (parseInt(amount) > 99) return message.reply("Le nombre maximum de messages que je peux supprimer est de 99");
    }

    const response = await purgeMessages(message.member, message.channel, "LINK", amount);

    if (typeof response === "number") {
      return message.channel.safeSend(`Supprimé avec succès ${response} messages`, 5);
    } else if (response === "BOT_PERM") {
      return message.reply("Je n'ai pas `Lire l'historique des messages` et `Gérer les messages` pour supprimer des messages");
    } else if (response === "MEMBER_PERM") {
      return message.reply("Vous n'avez pas `Lire l'historique des messages` et `Gérer les messages` pour supprimer des messages");
    } else if (response === "NO_MESSAGES") {
      return message.reply("Aucun message trouvé pouvant être clear");
    } else {
      return message.reply(`Erreur est survenue! Échec de la suppression des messages`);
    }
  }
};
