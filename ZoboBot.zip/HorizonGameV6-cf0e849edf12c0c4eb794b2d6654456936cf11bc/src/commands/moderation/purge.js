const { Message } = require("discord.js");
const { Command } = require("@src/structures");
const { purgeMessages } = require("@utils/modUtils");

module.exports = class PurgeCommand extends Command {
  constructor(client) {
    super(client, {
      name: "clear",
      description: "supprime le nombre spécifié de messages",
      category: "MODERATION",
      userPermissions: ["MANAGE_MESSAGES"],
      botPermissions: ["MANAGE_MESSAGES", "READ_MESSAGE_HISTORY"],
      command: {
        enabled: true,
        usage: "<amount>",
        minArgsCount: 1,
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   */
  async messageRun(message, args) {
    const amount = args[0];

    if (isNaN(amount)) return message.reply("Seuls les chiffres sont autorisés");
    if (parseInt(amount) > 99) return message.reply("Le nombre maximum de messages que je peux supprimer est de 99");

    const response = await purgeMessages(message.member, message.channel, "ALL", amount);

    if (typeof response === "number") {
      return message.channel.safeSend(`Supprimé avec succès ${response} messages`, 5);
    } else if (response === "BOT_PERM") {
      return message.reply("Je n'ai pas la permission de `Lire l'historique des messages` et `Gérer les messages` pour supprimer des messages");
    } else if (response === "MEMBER_PERM") {
      return message.reply("Vous n'avez pas la permission de `Lire l'historique des messages` et `Gérer les messages` pour supprimer des messages");
    } else if (response === "NO_MESSAGES") {
      return message.reply("Aucun message trouvé pouvant être clear");
    } else {
      return message.reply(`Erreur est survenue! Échec de la suppression des messages`);
    }
  }
};
