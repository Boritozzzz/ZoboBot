const { Command } = require("@src/structures");
const { timeoutTarget } = require("@utils/modUtils");
const { Message, CommandInteraction } = require("discord.js");

module.exports = class Timeout extends Command {
  constructor(client) {
    super(client, {
      name: "timeout",
      description: "timeout le membre spécifié",
      category: "MODERATION",
      botPermissions: ["MODERATE_MEMBERS"],
      userPermissions: ["MODERATE_MEMBERS"],
      command: {
        enabled: true,
        aliases: ["mute"],
        usage: "<ID|@member> <minutes> [raison]",
        minArgsCount: 1,
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "user",
            description: "le membre cible",
            type: "USER",
            required: true,
          },
          {
            name: "minutes",
            description: "le temps du timeout",
            type: "INTEGER",
            required: true,
          },
          {
            name: "reason",
            description: "raison du timeout",
            type: "STRING",
            required: false,
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   */
  async messageRun(message, args) {
    const target = await message.guild.resolveMember(args[0], true);
    if (!target) return message.reply(`Aucun utilisateur trouvé correspondant ${args[0]}`);
    const minutes = parseInt(args[1]);
    if (isNaN(minutes)) return message.reply("Temps invalide. Indiquez le temps en minutes.");
    const reason = args.slice(2).join(" ").trim();
    const response = await timeout(message.member, target, minutes, reason);
    await message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   */
  async interactionRun(interaction) {
    const user = interaction.options.getUser("user");
    const minutes = interaction.options.getInteger("minutes");
    const reason = interaction.options.getString("reason");
    const target = await interaction.guild.members.fetch(user.id);

    const response = await timeout(interaction.member, target, minutes, reason);
    await interaction.followUp(response);
  }
};

async function timeout(issuer, target, minutes, reason) {
  const response = await timeoutTarget(issuer, target, minutes, reason);
  if (typeof response === "boolean") return `${target.user.tag} est timeout!`;
  if (response === "BOT_PERM") return `Je n'ai pas la permission timeout ${target.user.tag}`;
  else if (response === "MEMBER_PERM") return `Vous n'êtes pas autorisé à timeout ${target.user.tag}`;
  else if (response === "ALREADY_TIMEOUT") return `${target.user.tag} est déjà timeout !`;
  else return `Échec du timeout de ${target.user.tag}`;
}
