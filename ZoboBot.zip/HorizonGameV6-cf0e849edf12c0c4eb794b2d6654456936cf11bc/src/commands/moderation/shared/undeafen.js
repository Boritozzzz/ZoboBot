const { unDeafenTarget } = require("@utils/modUtils");

module.exports = async ({ member }, target, reason) => {
  const response = await unDeafenTarget(member, target, reason);
  if (typeof response === "boolean") {
    return `${target.user.tag} n'est plus mute casque dans ce serveur`;
  }
  if (response === "MEMBER_PERM") {
    return `Vous n'avez pas l'autorisé de demute casque ${target.user.tag}`;
  }
  if (response === "BOT_PERM") {
    return `Je n'ai pas la permission de demute casque ${target.user.tag}`;
  }
  if (response === "NO_VOICE") {
    return `${target.user.tag} n'est dans aucun salon vocal`;
  }
  if (response === "NOT_DEAFENED") {
    return `${target.user.tag} n'est pas assourdi`;
  }
  return `Impossible erreur: ${target.user.tag}`;
};
