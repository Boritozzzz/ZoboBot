const { moveTarget } = require("@utils/modUtils");

module.exports = async ({ member }, target, reason, channel) => {
  const response = await moveTarget(member, target, reason, channel);
  if (typeof response === "boolean") {
    return `${target.user.tag} a été déplacer dans ce serveur`;
  }
  if (response === "MEMBER_PERM") {
    return `Vous n'êtes pas autorisé à déplacer ${target.user.tag}`;
  }
  if (response === "BOT_PERM") {
    return `je n'ai pas l'autorisation de me déplacer ${target.user.tag}`;
  }
  if (response === "NO_VOICE") {
    return `${target.user.tag} n'est dans aucun salon vocal`;
  }
  if (response === "TARGET_PERM") {
    return `${target.user.tag} n'a pas la permission de rejoindre ${channel}`;
  }
  if (response === "ALREADY_IN_CHANNEL") {
    return `${target.user.tag} est déjà connecté à ${channel}`;
  }
  return `Échec du déplacement ${target.user.tag} to ${channel}`;
};
