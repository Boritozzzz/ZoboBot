const { vMuteTarget } = require("@utils/modUtils");

module.exports = async ({ member }, target, reason) => {
  const response = await vMuteTarget(member, target, reason);
  if (typeof response === "boolean") {
    return `${target.user.tag}'s est mute micro sur ce serveur`;
  }
  if (response === "MEMBER_PERM") {
    return `Vous n'êtes pas autorisé à désactiver le micro ${target.user.tag}`;
  }
  if (response === "BOT_PERM") {
    return `Je n'ai pas la permission de désactiver le micro ${target.user.tag}`;
  }
  if (response === "NO_VOICE") {
    return `${target.user.tag} n'est dans aucun salon vocal`;
  }
  if (response === "ALREADY_MUTED") {
    return `${target.user.tag} est déjà mute micro`;
  }
  return `Échec de la désactivation du micro de ${target.user.tag}`;
};
