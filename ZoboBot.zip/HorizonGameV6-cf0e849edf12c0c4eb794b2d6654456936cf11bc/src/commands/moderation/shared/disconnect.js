const { disconnectTarget } = require("@utils/modUtils");

module.exports = async ({ member }, target, reason) => {
  const response = await disconnectTarget(member, target, reason);
  if (typeof response === "boolean") {
    return `${target.user.tag} est déconnecter dans ce serveur`;
  }
  if (response === "MEMBER_PERM") {
    return `Vous n'avez pas l'autorisé de déconnecter ${target.user.tag}`;
  }
  if (response === "BOT_PERM") {
    return `Je n'ai pas l'autorisé de déconnecter ${target.user.tag}`;
  }
  if (response === "NO_VOICE") {
    return `${target.user.tag} n'est dans aucun salon vocal`;
  }
  return `Impossible de déconnecter ${target.user.tag}`;
};
