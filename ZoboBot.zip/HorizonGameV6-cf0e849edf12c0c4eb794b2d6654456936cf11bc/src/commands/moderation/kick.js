const { Command } = require("@src/structures");
const { kickTarget } = require("@utils/modUtils");
const { Message, CommandInteraction } = require("discord.js");

module.exports = class KickCommand extends Command {
  constructor(client) {
    super(client, {
      name: "kick",
      description: "expulse le membre spécifié",
      category: "MODERATION",
      botPermissions: ["KICK_MEMBERS"],
      userPermissions: ["KICK_MEMBERS"],
      command: {
        enabled: true,
        usage: "<ID|@member> [raison]",
        minArgsCount: 1,
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "user",
            description: "le membre cible",
            type: "USER",
            required: true,
          },
          {
            name: "reason",
            description: "raison de l'expulsion ",
            type: "STRING",
            required: false,
          },
        ],
      },
    });
  }

  /**
   * @param {Message} message
   * @param {string[]} args
   */
  async messageRun(message, args) {
    const target = await message.guild.resolveMember(args[0], true);
    if (!target) return message.reply(`Aucun utilisateur trouvé correspondant ${args[0]}`);
    const reason = message.content.split(args[0])[1].trim();
    const response = await kick(message.member, target, reason);
    await message.reply(response);
  }

  /**
   * @param {CommandInteraction} interaction
   */
  async interactionRun(interaction) {
    const user = interaction.options.getUser("user");
    const reason = interaction.options.getString("reason");
    const target = await interaction.guild.members.fetch(user.id);

    const response = await kick(interaction.member, target, reason);
    await interaction.followUp(response);
  }
};

async function kick(issuer, target, reason) {
  const response = await kickTarget(issuer, target, reason);
  if (typeof response === "boolean") return `${target.user.tag} est kick!`;
  if (response === "BOT_PERM") return `Je n'ai pas la permission de kick ${target.user.tag}`;
  else if (response === "MEMBER_PERM") return `Vous n'êtes pas autorisé à kick ${target.user.tag}`;
  else return `Failed to warn ${target.user.tag}`;
}
