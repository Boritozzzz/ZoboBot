const { Command } = require("@src/structures");
const { CommandInteraction } = require("discord.js");
const { purgeMessages } = require("@utils/modUtils");

// SLASH COMMAND ONLY

module.exports = class PurgeCommand extends Command {
  constructor(client) {
    super(client, {
      name: "clear",
      description: "clear commandes",
      category: "MODERATION",
      userPermissions: ["MANAGE_MESSAGES"],
      command: {
        enabled: false,
      },
      slashCommand: {
        enabled: true,
        options: [
          {
            name: "all",
            description: "clear tous les messages",
            type: "SUB_COMMAND",
            options: [
              {
                name: "channel",
                description: "salon à partir duquel les messages doivent être nettoyés",
                type: "CHANNEL",
                channelTypes: ["GUILD_TEXT"],
                required: true,
              },
              {
                name: "amount",
                description: "nombre de messages à supprimer (Max 99)",
                type: "INTEGER",
                required: false,
              },
            ],
          },
          {
            name: "attachments",
            description: "clear tous les messages avec pièces jointes",
            type: "SUB_COMMAND",
            options: [
              {
                name: "channel",
                description: "salon à partir duquel les messages doivent être clear",
                type: "CHANNEL",
                channelTypes: ["GUILD_TEXT"],
                required: true,
              },
              {
                name: "amount",
                description: "nombre de messages à supprimer (Max 99)",
                type: "INTEGER",
                required: false,
              },
            ],
          },
          {
            name: "bots",
            description: "clear tous les messages du bot",
            type: "SUB_COMMAND",
            options: [
              {
                name: "channel",
                description: "salon à partir duquel les messages doivent être clear",
                type: "CHANNEL",
                channelTypes: ["GUILD_TEXT"],
                required: true,
              },
              {
                name: "amount",
                description: "nombre de messages à supprimer (Max 99)",
                type: "INTEGER",
                required: false,
              },
            ],
          },
          {
            name: "links",
            description: "clear tous les messages avec des liens",
            type: "SUB_COMMAND",
            options: [
              {
                name: "channel",
                description: "salon à partir duquel les messages doivent être clear",
                type: "CHANNEL",
                channelTypes: ["GUILD_TEXT"],
                required: true,
              },
              {
                name: "amount",
                description: "nombre de messages à supprimer (Max 99)",
                type: "INTEGER",
                required: false,
              },
            ],
          },
          {
            name: "token",
            description: "clear tous les messages contenant le jeton spécifié",
            type: "SUB_COMMAND",
            options: [
              {
                name: "channel",
                description: "salon à partir duquel les messages doivent être clear",
                type: "CHANNEL",
                channelTypes: ["GUILD_TEXT"],
                required: true,
              },
              {
                name: "token",
                description: "token à rechercher dans les messages",
                type: "STRING",
                required: true,
              },
              {
                name: "amount",
                description: "nombre de messages à supprimer (Max 99)",
                type: "INTEGER",
                required: false,
              },
            ],
          },
          {
            name: "user",
            description: "clear tous les messages de l'utilisateur spécifié",
            type: "SUB_COMMAND",
            options: [
              {
                name: "channel",
                description: "salon à partir duquel les messages doivent être clear",
                type: "CHANNEL",
                channelTypes: ["GUILD_TEXT"],
                required: true,
              },
              {
                name: "user",
                description: "utilisateur dont les messages doivent être clear",
                type: "USER",
                required: true,
              },
              {
                name: "amount",
                description: "nombre de messages à supprimer (Max 99)",
                type: "INTEGER",
                required: false,
              },
            ],
          },
        ],
      },
    });
  }

  /**
   * @param {CommandInteraction} interaction
   */
  async interactionRun(interaction) {
    const { options, member } = interaction;

    const sub = options.getSubcommand();
    const channel = options.getChannel("channel");
    const amount = options.getInteger("amount") || 99;

    let response;
    switch (sub) {
      case "all":
        response = await purgeMessages(member, channel, "ALL", amount);
        break;

      case "attachments":
        response = await purgeMessages(member, channel, "ATTACHMENT", amount);
        break;

      case "bots":
        response = await purgeMessages(member, channel, "BOT", amount);
        break;

      case "links":
        response = await purgeMessages(member, channel, "LINK", amount);
        break;

      case "token": {
        const token = interaction.options.getString("token");
        response = await purgeMessages(member, channel, "TOKEN", amount, token);
        break;
      }

      case "user": {
        const user = interaction.options.getUser("user");
        response = await purgeMessages(member, channel, "TOKEN", amount, user);
        break;
      }

      default:
        return interaction.followUp("Oups! Pas une sélection de commande valide");
    }

    // Success
    if (typeof response === "number") {
      const message = `Clear avec succès ${response} message dans ${channel}`;
      if (channel.id !== interaction.channelId) await interaction.followUp(message);
      else await channel.safeSend(message, 5);
      return;
    }

    // Member missing permissions
    else if (response === "MEMBER_PERM") {
      return interaction.followUp(
        `Vous n'êtes pas autorisé à lire l'historique des messages et à gérer les messages dans ${channel}`
      );
    }

    // Bot missing permissions
    else if (response === "BOT_PERM") {
      return interaction.followUp(`Je n'ai pas les autorisations pour lire l'historique des messages et gérer les messages dans ${channel}`);
    }

    // No messages
    else if (response === "NO_MESSAGES") {
      return interaction.followUp("Aucun message pouvant être clear trouvé");
    }

    // Remaining
    else {
      return interaction.followUp("Échec du nettoyage des messages");
    }
  }
};
