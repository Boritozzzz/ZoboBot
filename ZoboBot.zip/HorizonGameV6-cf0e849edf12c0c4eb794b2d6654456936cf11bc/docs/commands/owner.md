---
description: 1 command
---

# 🔏 Owner

| Command             | Slash     | Description        |
| ------------------- | --------- | ------------------ |
| **!eval \<script>** | **/eval** | Evaluates a script |
